export interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  volume: string;
  marketCap: string;
  exchange?: string;
  sector?: string;
  country?: string;
}

export interface StockInfo {
  symbol: string;
  name: string;
  exchange: string;
  sector: string;
  country: string;
}

export interface PriceHistory {
  symbol: string;
  prices: number[];
  timestamps: string[];
}

export interface TechnicalIndicators {
  rsi: number;
  macd: number;
  ma20: number;
  ma50: number;
  ma200: number;
  bollingerUpper: number;
  bollingerLower: number;
}

export const allStocks: StockInfo[] = [
  // US Tech Giants
  { symbol: "NASDAQ:AAPL", name: "Apple Inc.", exchange: "NASDAQ", sector: "Technology", country: "US" },
  { symbol: "NASDAQ:GOOGL", name: "Alphabet Inc.", exchange: "NASDAQ", sector: "Technology", country: "US" },
  { symbol: "NASDAQ:MSFT", name: "Microsoft Corp.", exchange: "NASDAQ", sector: "Technology", country: "US" },
  { symbol: "NASDAQ:AMZN", name: "Amazon.com Inc.", exchange: "NASDAQ", sector: "Consumer", country: "US" },
  { symbol: "NASDAQ:TSLA", name: "Tesla Inc.", exchange: "NASDAQ", sector: "Automotive", country: "US" },
  { symbol: "NASDAQ:META", name: "Meta Platforms", exchange: "NASDAQ", sector: "Technology", country: "US" },
  { symbol: "NASDAQ:NVDA", name: "NVIDIA Corp.", exchange: "NASDAQ", sector: "Technology", country: "US" },
  { symbol: "NYSE:JPM", name: "JPMorgan Chase", exchange: "NYSE", sector: "Banking", country: "US" },
  
  // Indian Indices
  { symbol: "NSE:NIFTY50", name: "Nifty 50 Index", exchange: "NSE", sector: "Index", country: "IN" },
  { symbol: "BSE:SENSEX", name: "BSE Sensex", exchange: "BSE", sector: "Index", country: "IN" },
  { symbol: "NSE:BANKNIFTY", name: "Nifty Bank Index", exchange: "NSE", sector: "Index", country: "IN" },
  
  // Indian Large Cap - Banking & Finance
  { symbol: "NSE:RELIANCE", name: "Reliance Industries", exchange: "NSE", sector: "Conglomerate", country: "IN" },
  { symbol: "NSE:HDFCBANK", name: "HDFC Bank Ltd.", exchange: "NSE", sector: "Banking", country: "IN" },
  { symbol: "NSE:ICICIBANK", name: "ICICI Bank Ltd.", exchange: "NSE", sector: "Banking", country: "IN" },
  { symbol: "NSE:SBIN", name: "State Bank of India", exchange: "NSE", sector: "Banking", country: "IN" },
  { symbol: "NSE:KOTAKBANK", name: "Kotak Mahindra Bank", exchange: "NSE", sector: "Banking", country: "IN" },
  { symbol: "NSE:AXISBANK", name: "Axis Bank Ltd.", exchange: "NSE", sector: "Banking", country: "IN" },
  { symbol: "NSE:BAJFINANCE", name: "Bajaj Finance Ltd.", exchange: "NSE", sector: "Finance", country: "IN" },
  { symbol: "NSE:BAJAJFINSV", name: "Bajaj Finserv Ltd.", exchange: "NSE", sector: "Finance", country: "IN" },
  
  // Indian IT Companies
  { symbol: "NSE:TCS", name: "Tata Consultancy Services", exchange: "NSE", sector: "IT", country: "IN" },
  { symbol: "NSE:INFY", name: "Infosys Ltd.", exchange: "NSE", sector: "IT", country: "IN" },
  { symbol: "NSE:HCLTECH", name: "HCL Technologies", exchange: "NSE", sector: "IT", country: "IN" },
  { symbol: "NSE:WIPRO", name: "Wipro Ltd.", exchange: "NSE", sector: "IT", country: "IN" },
  { symbol: "NSE:TECHM", name: "Tech Mahindra Ltd.", exchange: "NSE", sector: "IT", country: "IN" },
  { symbol: "NSE:LTI", name: "L&T Infotech", exchange: "NSE", sector: "IT", country: "IN" },
  
  // Indian Automobiles
  { symbol: "NSE:MARUTI", name: "Maruti Suzuki India", exchange: "NSE", sector: "Automobiles", country: "IN" },
  { symbol: "NSE:TATAMOTORS", name: "Tata Motors Ltd.", exchange: "NSE", sector: "Automobiles", country: "IN" },
  { symbol: "NSE:M&M", name: "Mahindra & Mahindra", exchange: "NSE", sector: "Automobiles", country: "IN" },
  { symbol: "NSE:BAJAJ-AUTO", name: "Bajaj Auto Ltd.", exchange: "NSE", sector: "Automobiles", country: "IN" },
  { symbol: "NSE:HEROMOTOCO", name: "Hero MotoCorp Ltd.", exchange: "NSE", sector: "Automobiles", country: "IN" },
  { symbol: "NSE:EICHERMOT", name: "Eicher Motors Ltd.", exchange: "NSE", sector: "Automobiles", country: "IN" },
  
  // Indian FMCG & Consumer
  { symbol: "NSE:HINDUNILVR", name: "Hindustan Unilever", exchange: "NSE", sector: "FMCG", country: "IN" },
  { symbol: "NSE:ITC", name: "ITC Ltd.", exchange: "NSE", sector: "FMCG", country: "IN" },
  { symbol: "NSE:NESTLEIND", name: "Nestle India Ltd.", exchange: "NSE", sector: "FMCG", country: "IN" },
  { symbol: "NSE:BRITANNIA", name: "Britannia Industries", exchange: "NSE", sector: "FMCG", country: "IN" },
  { symbol: "NSE:TITAN", name: "Titan Company Ltd.", exchange: "NSE", sector: "Consumer", country: "IN" },
  { symbol: "NSE:DABUR", name: "Dabur India Ltd.", exchange: "NSE", sector: "FMCG", country: "IN" },
  
  // Indian Pharma
  { symbol: "NSE:SUNPHARMA", name: "Sun Pharmaceutical", exchange: "NSE", sector: "Pharma", country: "IN" },
  { symbol: "NSE:DRREDDY", name: "Dr. Reddy's Labs", exchange: "NSE", sector: "Pharma", country: "IN" },
  { symbol: "NSE:CIPLA", name: "Cipla Ltd.", exchange: "NSE", sector: "Pharma", country: "IN" },
  { symbol: "NSE:DIVISLAB", name: "Divi's Laboratories", exchange: "NSE", sector: "Pharma", country: "IN" },
  { symbol: "NSE:BIOCON", name: "Biocon Ltd.", exchange: "NSE", sector: "Pharma", country: "IN" },
  
  // Indian Energy & Power
  { symbol: "NSE:ONGC", name: "Oil & Natural Gas Corp", exchange: "NSE", sector: "Energy", country: "IN" },
  { symbol: "NSE:NTPC", name: "NTPC Ltd.", exchange: "NSE", sector: "Power", country: "IN" },
  { symbol: "NSE:POWERGRID", name: "Power Grid Corp", exchange: "NSE", sector: "Power", country: "IN" },
  { symbol: "NSE:BPCL", name: "Bharat Petroleum", exchange: "NSE", sector: "Energy", country: "IN" },
  { symbol: "NSE:IOC", name: "Indian Oil Corp", exchange: "NSE", sector: "Energy", country: "IN" },
  { symbol: "NSE:ADANIGREEN", name: "Adani Green Energy", exchange: "NSE", sector: "Renewable", country: "IN" },
  { symbol: "NSE:TATAPOWER", name: "Tata Power Co.", exchange: "NSE", sector: "Power", country: "IN" },
  
  // Indian Infrastructure
  { symbol: "NSE:LT", name: "Larsen & Toubro", exchange: "NSE", sector: "Infrastructure", country: "IN" },
  { symbol: "NSE:ADANIPORTS", name: "Adani Ports & SEZ", exchange: "NSE", sector: "Infrastructure", country: "IN" },
  { symbol: "NSE:ULTRACEMCO", name: "UltraTech Cement", exchange: "NSE", sector: "Cement", country: "IN" },
  { symbol: "NSE:GRASIM", name: "Grasim Industries", exchange: "NSE", sector: "Cement", country: "IN" },
  { symbol: "NSE:SHREECEM", name: "Shree Cement Ltd.", exchange: "NSE", sector: "Cement", country: "IN" },
  
  // Indian Telecom
  { symbol: "NSE:BHARTIARTL", name: "Bharti Airtel Ltd.", exchange: "NSE", sector: "Telecom", country: "IN" },
  
  // Indian Metals & Mining
  { symbol: "NSE:TATASTEEL", name: "Tata Steel Ltd.", exchange: "NSE", sector: "Metals", country: "IN" },
  { symbol: "NSE:HINDALCO", name: "Hindalco Industries", exchange: "NSE", sector: "Metals", country: "IN" },
  { symbol: "NSE:JSWSTEEL", name: "JSW Steel Ltd.", exchange: "NSE", sector: "Metals", country: "IN" },
  { symbol: "NSE:COALINDIA", name: "Coal India Ltd.", exchange: "NSE", sector: "Mining", country: "IN" },
  { symbol: "NSE:VEDL", name: "Vedanta Ltd.", exchange: "NSE", sector: "Metals", country: "IN" },
  
  // Indian Defense & PSU
  { symbol: "NSE:BEL", name: "Bharat Electronics", exchange: "NSE", sector: "Defense", country: "IN" },
  { symbol: "NSE:HAL", name: "Hindustan Aeronautics", exchange: "NSE", sector: "Defense", country: "IN" },
  
  // Crypto
  { symbol: "BINANCE:BTCUSDT", name: "Bitcoin", exchange: "Crypto", sector: "Crypto", country: "Global" },
  { symbol: "BINANCE:ETHUSDT", name: "Ethereum", exchange: "Crypto", sector: "Crypto", country: "Global" },
  { symbol: "BINANCE:SOLUSDT", name: "Solana", exchange: "Crypto", sector: "Crypto", country: "Global" },
  { symbol: "BINANCE:BNBUSDT", name: "BNB", exchange: "Crypto", sector: "Crypto", country: "Global" },
  
  // Commodities
  { symbol: "TVC:GOLD", name: "Gold", exchange: "Commodities", sector: "Precious Metals", country: "Global" },
  { symbol: "TVC:SILVER", name: "Silver", exchange: "Commodities", sector: "Precious Metals", country: "Global" },
  { symbol: "NYMEX:CL1!", name: "Crude Oil WTI", exchange: "Commodities", sector: "Energy", country: "Global" },
  
  // Forex
  { symbol: "FX:USDINR", name: "USD/INR", exchange: "Forex", sector: "Currency", country: "Global" },
  { symbol: "FX:EURUSD", name: "EUR/USD", exchange: "Forex", sector: "Currency", country: "Global" },
  { symbol: "FX:GBPUSD", name: "GBP/USD", exchange: "Forex", sector: "Currency", country: "Global" },
];

const basePrices: Record<string, number> = {
  "NASDAQ:AAPL": 178.52,
  "NASDAQ:GOOGL": 141.80,
  "NASDAQ:MSFT": 378.91,
  "NASDAQ:AMZN": 178.25,
  "NASDAQ:TSLA": 248.50,
  "NASDAQ:META": 505.75,
  "NASDAQ:NVDA": 875.28,
  "NYSE:JPM": 195.40,
  "BINANCE:BTCUSDT": 97250.00,
  "BINANCE:ETHUSDT": 3520.45,
  "BINANCE:SOLUSDT": 185.60,
  "BINANCE:BNBUSDT": 685.40,
  "TVC:GOLD": 2685.80,
  "TVC:SILVER": 31.45,
  "FX:USDINR": 83.45,
  "FX:EURUSD": 1.0875,
  "FX:GBPUSD": 1.2650,
  "NSE:NIFTY50": 23456.80,
  "BSE:SENSEX": 77450.25,
  "NSE:BANKNIFTY": 49875.60,
  "NSE:RELIANCE": 2895.50,
  "NSE:HDFCBANK": 1710.30,
  "NSE:ICICIBANK": 1245.75,
  "NSE:SBIN": 785.40,
  "NSE:TCS": 4125.80,
  "NSE:INFY": 1845.25,
  "NSE:KOTAKBANK": 1875.90,
  "NSE:AXISBANK": 1125.60,
  "NSE:BHARTIARTL": 1685.40,
  "NSE:ITC": 465.75,
  "NSE:HINDUNILVR": 2545.30,
  "NSE:MARUTI": 12450.80,
  "NSE:TATAMOTORS": 985.40,
  "NSE:M&M": 2875.60,
  "NSE:SUNPHARMA": 1745.25,
  "NSE:TITAN": 3580.90,
  "NSE:LT": 3625.40,
  "NSE:BAJFINANCE": 7245.80,
  "NSE:BAJAJFINSV": 1685.40,
  "NSE:NTPC": 385.60,
  "NSE:ONGC": 275.40,
  "NSE:TATASTEEL": 145.75,
  "NSE:WIPRO": 485.30,
  "NSE:HCLTECH": 1785.60,
  "NSE:TECHM": 1625.80,
  "NSE:ADANIPORTS": 1285.40,
  "NSE:ULTRACEMCO": 11250.75,
  "NSE:DRREDDY": 6785.40,
  "NSE:CIPLA": 1525.60,
  "NSE:DIVISLAB": 4125.80,
  "NSE:POWERGRID": 325.40,
  "NSE:BPCL": 585.60,
  "NSE:IOC": 145.80,
  "NSE:ADANIGREEN": 1875.40,
  "NSE:TATAPOWER": 425.60,
  "NSE:GRASIM": 2685.40,
  "NSE:SHREECEM": 27450.80,
  "NSE:HINDALCO": 625.40,
  "NSE:JSWSTEEL": 945.60,
  "NSE:COALINDIA": 485.40,
  "NSE:VEDL": 445.60,
  "NSE:BEL": 285.40,
  "NSE:HAL": 4525.60,
  "NSE:BAJAJ-AUTO": 9245.80,
  "NSE:HEROMOTOCO": 4875.60,
  "NSE:EICHERMOT": 4625.40,
  "NSE:NESTLEIND": 2485.60,
  "NSE:BRITANNIA": 5245.80,
  "NSE:DABUR": 545.60,
  "NSE:BIOCON": 345.40,
  "NSE:LTI": 5685.60,
  "NYMEX:CL1!": 78.45,
};

function getRandomVariation(basePrice: number, maxPercent: number = 2): number {
  const variation = (Math.random() - 0.5) * 2 * (maxPercent / 100);
  return basePrice * (1 + variation);
}

export function getStockQuote(symbol: string): StockQuote {
  const stockInfo = allStocks.find(s => s.symbol === symbol);
  
  const basePrice = basePrices[symbol] || 100 + Math.random() * 200;
  const price = getRandomVariation(basePrice, 1);
  const change = price - basePrice;
  const changePercent = (change / basePrice) * 100;
  const high = price * (1 + Math.random() * 0.02);
  const low = price * (1 - Math.random() * 0.02);

  const displaySymbol = symbol.split(':')[1] || symbol;
  const isIndian = symbol.startsWith('NSE:') || symbol.startsWith('BSE:');
  const volume = `${Math.floor(Math.random() * 100 + 10)}.${Math.floor(Math.random() * 9)}M`;

  return {
    symbol,
    name: stockInfo?.name || displaySymbol,
    price: parseFloat(price.toFixed(2)),
    change: parseFloat(change.toFixed(2)),
    changePercent: parseFloat(changePercent.toFixed(2)),
    high: parseFloat(high.toFixed(2)),
    low: parseFloat(low.toFixed(2)),
    volume,
    marketCap: getMarketCap(symbol, isIndian),
    exchange: stockInfo?.exchange,
    sector: stockInfo?.sector,
    country: stockInfo?.country,
  };
}

function getMarketCap(symbol: string, isIndian: boolean): string {
  if (symbol.includes("BTCUSDT")) return "1.9T";
  if (symbol.includes("AAPL") || symbol.includes("MSFT")) return "2.8T";
  if (symbol.includes("NVDA")) return "2.1T";
  if (symbol.includes("RELIANCE")) return "₹19.5L Cr";
  if (symbol.includes("TCS")) return "₹15.2L Cr";
  if (symbol.includes("HDFCBANK")) return "₹12.8L Cr";
  if (symbol.includes("INFY")) return "₹7.6L Cr";
  if (symbol.includes("ICICIBANK")) return "₹8.7L Cr";
  
  const cap = Math.floor(Math.random() * 500) + 50;
  return isIndian ? `₹${cap}K Cr` : `${cap}B`;
}

export function getPriceHistory(symbol: string, days: number = 30): PriceHistory {
  const basePrice = basePrices[symbol] || 100 + Math.random() * 200;
  const prices: number[] = [];
  const timestamps: string[] = [];
  
  let currentPrice = basePrice * (0.9 + Math.random() * 0.2);
  const now = Date.now();
  
  for (let i = days; i >= 0; i--) {
    currentPrice = currentPrice * (1 + (Math.random() - 0.48) * 0.03);
    prices.push(parseFloat(currentPrice.toFixed(2)));
    timestamps.push(new Date(now - i * 24 * 60 * 60 * 1000).toISOString());
  }
  
  return { symbol, prices, timestamps };
}

export function getHourlyPrices(symbol: string, hours: number = 24): number[] {
  const basePrice = basePrices[symbol] || 100 + Math.random() * 200;
  const prices: number[] = [];
  
  let currentPrice = basePrice * (0.98 + Math.random() * 0.04);
  
  for (let i = 0; i < hours; i++) {
    currentPrice = currentPrice * (1 + (Math.random() - 0.48) * 0.01);
    prices.push(parseFloat(currentPrice.toFixed(2)));
  }
  
  return prices;
}

export function calculateIndicators(prices: number[]): TechnicalIndicators {
  const changes = prices.slice(1).map((p, i) => p - prices[i]);
  const gains = changes.filter(c => c > 0);
  const losses = changes.filter(c => c < 0).map(c => Math.abs(c));
  
  const avgGain = gains.length > 0 ? gains.reduce((a, b) => a + b, 0) / 14 : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / 14 : 0.01;
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));

  const ma20 = prices.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, prices.length);
  const ma50 = prices.slice(-50).reduce((a, b) => a + b, 0) / Math.min(50, prices.length);
  const ma200 = prices.slice(-200).reduce((a, b) => a + b, 0) / Math.min(200, prices.length);

  const ema12 = prices.slice(-12).reduce((a, b) => a + b, 0) / Math.min(12, prices.length);
  const ema26 = prices.slice(-26).reduce((a, b) => a + b, 0) / Math.min(26, prices.length);
  const macd = ema12 - ema26;

  const stdDev = Math.sqrt(
    prices.slice(-20).reduce((sum, p) => sum + Math.pow(p - ma20, 2), 0) / 
    Math.min(20, prices.length)
  );
  const bollingerUpper = ma20 + (2 * stdDev);
  const bollingerLower = ma20 - (2 * stdDev);

  return {
    rsi: parseFloat(Math.min(100, Math.max(0, rsi)).toFixed(1)),
    macd: parseFloat(macd.toFixed(2)),
    ma20: parseFloat(ma20.toFixed(2)),
    ma50: parseFloat(ma50.toFixed(2)),
    ma200: parseFloat(ma200.toFixed(2)),
    bollingerUpper: parseFloat(bollingerUpper.toFixed(2)),
    bollingerLower: parseFloat(bollingerLower.toFixed(2))
  };
}

export function getStocksByCountry(country: string): StockInfo[] {
  return allStocks.filter(s => s.country === country);
}

export function getStocksBySector(sector: string): StockInfo[] {
  return allStocks.filter(s => s.sector === sector);
}

export function getStocksByExchange(exchange: string): StockInfo[] {
  return allStocks.filter(s => s.exchange === exchange);
}

export function searchStocks(query: string): StockInfo[] {
  const q = query.toLowerCase();
  return allStocks.filter(s => 
    s.symbol.toLowerCase().includes(q) || 
    s.name.toLowerCase().includes(q) ||
    s.sector.toLowerCase().includes(q)
  );
}

export function getMarketNews(): string[] {
  const headlines = [
    "Tech stocks surge as AI optimism fuels market rally",
    "RBI holds rates steady, signals accommodative stance",
    "Nifty 50 hits all-time high amid foreign inflows",
    "Reliance Industries announces major expansion plans",
    "TCS, Infosys report strong quarterly earnings",
    "HDFC Bank merger integration progressing well",
    "Auto sector sees revival with festive demand",
    "Pharma stocks gain on FDA approval news",
    "IT sector outlook positive for FY26",
    "Banking sector shows resilience in quarterly reports"
  ];
  
  const shuffled = headlines.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, 5 + Math.floor(Math.random() * 3));
}
