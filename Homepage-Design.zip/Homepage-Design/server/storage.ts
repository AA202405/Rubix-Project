import { 
  type User, 
  type InsertUser, 
  type PortfolioHolding, 
  type Trade,
  type Achievement
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: string, balance: number): Promise<void>;
  
  getPortfolioHoldings(userId: string): Promise<PortfolioHolding[]>;
  getHolding(userId: string, symbol: string): Promise<PortfolioHolding | undefined>;
  upsertHolding(userId: string, symbol: string, quantity: number, avgPrice: number): Promise<PortfolioHolding>;
  deleteHolding(userId: string, symbol: string): Promise<void>;
  
  getTrades(userId: string): Promise<Trade[]>;
  addTrade(trade: Omit<Trade, 'id' | 'createdAt'>): Promise<Trade>;
  
  getAchievements(userId: string): Promise<Achievement[]>;
  addAchievement(userId: string, type: string): Promise<Achievement>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private holdings: Map<string, PortfolioHolding>;
  private trades: Map<string, Trade>;
  private achievements: Map<string, Achievement>;

  constructor() {
    this.users = new Map();
    this.holdings = new Map();
    this.trades = new Map();
    this.achievements = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      email: insertUser.email,
      password: insertUser.password,
      name: insertUser.name || null,
      id,
      virtualBalance: 1000000,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(userId: string, balance: number): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.virtualBalance = balance;
      this.users.set(userId, user);
    }
  }

  async getPortfolioHoldings(userId: string): Promise<PortfolioHolding[]> {
    return Array.from(this.holdings.values()).filter(h => h.userId === userId);
  }

  async getHolding(userId: string, symbol: string): Promise<PortfolioHolding | undefined> {
    return Array.from(this.holdings.values()).find(
      h => h.userId === userId && h.symbol === symbol
    );
  }

  async upsertHolding(userId: string, symbol: string, quantity: number, avgPrice: number): Promise<PortfolioHolding> {
    const existingKey = Array.from(this.holdings.entries()).find(
      ([_, h]) => h.userId === userId && h.symbol === symbol
    )?.[0];

    if (existingKey) {
      const holding = this.holdings.get(existingKey)!;
      holding.quantity = quantity;
      holding.avgBuyPrice = avgPrice;
      this.holdings.set(existingKey, holding);
      return holding;
    } else {
      const id = randomUUID();
      const holding: PortfolioHolding = {
        id,
        userId,
        symbol,
        quantity,
        avgBuyPrice: avgPrice,
        createdAt: new Date(),
      };
      this.holdings.set(id, holding);
      return holding;
    }
  }

  async deleteHolding(userId: string, symbol: string): Promise<void> {
    const key = Array.from(this.holdings.entries()).find(
      ([_, h]) => h.userId === userId && h.symbol === symbol
    )?.[0];
    if (key) {
      this.holdings.delete(key);
    }
  }

  async getTrades(userId: string): Promise<Trade[]> {
    return Array.from(this.trades.values())
      .filter(t => t.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async addTrade(trade: Omit<Trade, 'id' | 'createdAt'>): Promise<Trade> {
    const id = randomUUID();
    const newTrade: Trade = {
      ...trade,
      id,
      createdAt: new Date(),
    };
    this.trades.set(id, newTrade);
    return newTrade;
  }

  async getAchievements(userId: string): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(a => a.userId === userId);
  }

  async addAchievement(userId: string, type: string): Promise<Achievement> {
    const id = randomUUID();
    const achievement: Achievement = {
      id,
      userId,
      type,
      unlockedAt: new Date(),
    };
    this.achievements.set(id, achievement);
    return achievement;
  }
}

export const storage = new MemStorage();
