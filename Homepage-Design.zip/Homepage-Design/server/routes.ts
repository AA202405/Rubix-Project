import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  getStockQuote, 
  getPriceHistory, 
  getHourlyPrices, 
  calculateIndicators,
  getMarketNews,
  allStocks,
  searchStocks,
  getStocksByCountry,
  getStocksBySector
} from "./stock-data";
import { analyzeTrend, analyzeSentiment, generateTradingSignal } from "./gemini";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, name } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }

      const existing = await storage.getUserByEmail(email);
      if (existing) {
        return res.status(400).json({ error: "Email already registered" });
      }

      const user = await storage.createUser({ email, password, name });
      
      await storage.addAchievement(user.id, "first_login");
      
      res.json({ 
        id: user.id, 
        email: user.email, 
        name: user.name,
        virtualBalance: user.virtualBalance
      });
    } catch (error) {
      console.error("Error registering user:", error);
      res.status(500).json({ error: "Failed to register user" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }

      const user = await storage.getUserByEmail(email);
      
      if (!user) {
        const newUser = await storage.createUser({ email, password, name: email.split('@')[0] });
        await storage.addAchievement(newUser.id, "first_login");
        return res.json({ 
          id: newUser.id, 
          email: newUser.email, 
          name: newUser.name,
          virtualBalance: newUser.virtualBalance
        });
      }
      
      if (user.password !== password) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      res.json({ 
        id: user.id, 
        email: user.email, 
        name: user.name,
        virtualBalance: user.virtualBalance
      });
    } catch (error) {
      console.error("Error logging in:", error);
      res.status(500).json({ error: "Failed to login" });
    }
  });

  app.get("/api/user/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ 
        id: user.id, 
        email: user.email, 
        name: user.name,
        virtualBalance: user.virtualBalance
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.get("/api/portfolio/:userId", async (req, res) => {
    try {
      const holdings = await storage.getPortfolioHoldings(req.params.userId);
      const user = await storage.getUser(req.params.userId);
      
      let totalValue = 0;
      let totalInvested = 0;
      
      const enrichedHoldings = holdings.map(h => {
        const quote = getStockQuote(h.symbol);
        const currentValue = h.quantity * quote.price;
        const invested = h.quantity * h.avgBuyPrice;
        const pnl = currentValue - invested;
        const pnlPercent = (pnl / invested) * 100;
        
        totalValue += currentValue;
        totalInvested += invested;
        
        return {
          ...h,
          currentPrice: quote.price,
          currentValue,
          pnl,
          pnlPercent,
          name: quote.name
        };
      });
      
      res.json({
        holdings: enrichedHoldings,
        totalValue,
        totalInvested,
        totalPnl: totalValue - totalInvested,
        cashBalance: user?.virtualBalance ?? 1000000
      });
    } catch (error) {
      console.error("Error fetching portfolio:", error);
      res.status(500).json({ error: "Failed to fetch portfolio" });
    }
  });

  app.post("/api/trade", async (req, res) => {
    try {
      const { userId, symbol, type, quantity, userEmail } = req.body;
      
      if (!userId || !symbol || !type || !quantity) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      let user = await storage.getUser(userId);
      
      if (!user && userEmail) {
        user = await storage.createUser({ 
          email: userEmail, 
          password: 'auto', 
          name: userEmail.split('@')[0] 
        });
      }
      
      if (!user) {
        return res.status(404).json({ error: "User not found. Please sign in again." });
      }

      const quote = getStockQuote(symbol);
      const total = quantity * quote.price;

      if (type === "buy") {
        if ((user.virtualBalance || 0) < total) {
          return res.status(400).json({ error: "Insufficient balance" });
        }
        
        await storage.updateUserBalance(userId, (user.virtualBalance || 0) - total);
        
        const existing = await storage.getHolding(userId, symbol);
        if (existing) {
          const newQty = existing.quantity + quantity;
          const newAvg = ((existing.quantity * existing.avgBuyPrice) + total) / newQty;
          await storage.upsertHolding(userId, symbol, newQty, newAvg);
        } else {
          await storage.upsertHolding(userId, symbol, quantity, quote.price);
        }
        
        const trades = await storage.getTrades(userId);
        if (trades.length === 0) {
          await storage.addAchievement(userId, "first_trade");
        }
        if (trades.length >= 9) {
          await storage.addAchievement(userId, "ten_trades");
        }
        
      } else if (type === "sell") {
        const existing = await storage.getHolding(userId, symbol);
        if (!existing || existing.quantity < quantity) {
          return res.status(400).json({ error: "Insufficient holdings" });
        }
        
        await storage.updateUserBalance(userId, (user.virtualBalance || 0) + total);
        
        const newQty = existing.quantity - quantity;
        if (newQty === 0) {
          await storage.deleteHolding(userId, symbol);
        } else {
          await storage.upsertHolding(userId, symbol, newQty, existing.avgBuyPrice);
        }
        
        const pnl = (quote.price - existing.avgBuyPrice) * quantity;
        if (pnl > 0) {
          const achievements = await storage.getAchievements(userId);
          if (!achievements.find(a => a.type === "first_profit")) {
            await storage.addAchievement(userId, "first_profit");
          }
        }
      }

      await storage.addTrade({
        userId,
        symbol,
        type,
        quantity,
        price: quote.price,
        total
      });

      res.json({ success: true, price: quote.price, total });
    } catch (error) {
      console.error("Error executing trade:", error);
      res.status(500).json({ error: "Failed to execute trade" });
    }
  });

  app.get("/api/trades/:userId", async (req, res) => {
    try {
      const trades = await storage.getTrades(req.params.userId);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trades" });
    }
  });

  app.get("/api/achievements/:userId", async (req, res) => {
    try {
      const achievements = await storage.getAchievements(req.params.userId);
      res.json(achievements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch achievements" });
    }
  });

  app.get("/api/stocks", async (req, res) => {
    try {
      const { country, sector, search } = req.query;
      
      let stocks = allStocks;
      
      if (search) {
        stocks = searchStocks(search as string);
      } else if (country) {
        stocks = getStocksByCountry(country as string);
      } else if (sector) {
        stocks = getStocksBySector(sector as string);
      }
      
      const enriched = stocks.map(s => ({
        ...s,
        ...getStockQuote(s.symbol)
      }));
      
      res.json(enriched);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stocks" });
    }
  });

  app.get("/api/stocks/:symbol", async (req, res) => {
    try {
      const symbol = decodeURIComponent(req.params.symbol);
      const quote = getStockQuote(symbol);
      res.json(quote);
    } catch (error) {
      console.error("Error fetching stock quote:", error);
      res.status(500).json({ error: "Failed to fetch stock quote" });
    }
  });

  app.get("/api/stocks/:symbol/history", async (req, res) => {
    try {
      const symbol = decodeURIComponent(req.params.symbol);
      const days = parseInt(req.query.days as string) || 30;
      const history = getPriceHistory(symbol, days);
      res.json(history);
    } catch (error) {
      console.error("Error fetching price history:", error);
      res.status(500).json({ error: "Failed to fetch price history" });
    }
  });

  app.get("/api/stocks/:symbol/indicators", async (req, res) => {
    try {
      const symbol = decodeURIComponent(req.params.symbol);
      const history = getPriceHistory(symbol, 200);
      const indicators = calculateIndicators(history.prices);
      res.json(indicators);
    } catch (error) {
      console.error("Error calculating indicators:", error);
      res.status(500).json({ error: "Failed to calculate indicators" });
    }
  });

  app.post("/api/ai/trend-prediction", async (req, res) => {
    try {
      const { symbol } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ error: "Symbol is required" });
      }

      const hourlyPrices = getHourlyPrices(symbol, 24);
      const prediction = await analyzeTrend(symbol, hourlyPrices);
      
      res.json(prediction);
    } catch (error) {
      console.error("Error generating trend prediction:", error);
      res.status(500).json({ error: "Failed to generate trend prediction" });
    }
  });

  app.post("/api/ai/sentiment-analysis", async (req, res) => {
    try {
      const { symbol } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ error: "Symbol is required" });
      }

      const headlines = getMarketNews();
      const sentiment = await analyzeSentiment(symbol, headlines);
      
      res.json({
        ...sentiment,
        headlines
      });
    } catch (error) {
      console.error("Error analyzing sentiment:", error);
      res.status(500).json({ error: "Failed to analyze sentiment" });
    }
  });

  app.post("/api/ai/trading-signal", async (req, res) => {
    try {
      const { symbol } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ error: "Symbol is required" });
      }

      const hourlyPrices = getHourlyPrices(symbol, 24);
      const history = getPriceHistory(symbol, 200);
      const indicators = calculateIndicators(history.prices);
      
      const signal = await generateTradingSignal(symbol, hourlyPrices, {
        rsi: indicators.rsi,
        macd: indicators.macd,
        ma20: indicators.ma20,
        ma50: indicators.ma50
      });
      
      res.json({
        ...signal,
        indicators
      });
    } catch (error) {
      console.error("Error generating trading signal:", error);
      res.status(500).json({ error: "Failed to generate trading signal" });
    }
  });

  app.post("/api/ai/backtest", async (req, res) => {
    try {
      const { symbol, strategy } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ error: "Symbol is required" });
      }

      const history = getPriceHistory(symbol, 90);
      const prices = history.prices;
      const indicators = calculateIndicators(prices);
      
      let trades = 0;
      let wins = 0;
      let totalProfit = 0;
      let winProfits: number[] = [];
      let lossProfits: number[] = [];
      let maxDrawdown = 0;
      let peakValue = 10000;
      let currentValue = 10000;
      
      for (let i = 20; i < prices.length - 1; i++) {
        const recentPrices = prices.slice(i - 20, i);
        const ma5 = recentPrices.slice(-5).reduce((a, b) => a + b, 0) / 5;
        const ma20 = recentPrices.reduce((a, b) => a + b, 0) / 20;
        
        let shouldBuy = false;
        
        if (strategy === "momentum") {
          shouldBuy = ma5 > ma20 && prices[i] > prices[i - 1];
        } else if (strategy === "value") {
          const rsi = calculateRSI(recentPrices);
          shouldBuy = rsi < 40;
        } else if (strategy === "growth") {
          shouldBuy = prices[i] > ma20 * 1.02;
        } else {
          shouldBuy = ma5 > ma20;
        }
        
        const actualMove = prices[i + 1] - prices[i];
        const predicted = shouldBuy ? 1 : -1;
        const actual = actualMove > 0 ? 1 : -1;
        
        trades++;
        const profitPercent = (actualMove / prices[i]) * 100;
        
        if (predicted === actual) {
          wins++;
          winProfits.push(Math.abs(profitPercent));
          currentValue *= (1 + Math.abs(profitPercent) / 100);
          totalProfit += Math.abs(profitPercent);
        } else {
          lossProfits.push(Math.abs(profitPercent));
          currentValue *= (1 - Math.abs(profitPercent) / 100 * 0.5);
          totalProfit -= Math.abs(profitPercent) * 0.5;
        }
        
        if (currentValue > peakValue) {
          peakValue = currentValue;
        }
        const drawdown = (peakValue - currentValue) / peakValue * 100;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
      
      const avgWin = winProfits.length > 0 
        ? winProfits.reduce((a, b) => a + b, 0) / winProfits.length 
        : 0;
      const avgLoss = lossProfits.length > 0 
        ? lossProfits.reduce((a, b) => a + b, 0) / lossProfits.length 
        : 0;
      
      const sharpeRatio = (totalProfit / trades) / (avgLoss || 1) * Math.sqrt(252);
      
      res.json({
        totalTrades: trades,
        winRate: Math.round((wins / trades) * 100),
        profit: totalProfit.toFixed(1),
        avgWin: avgWin.toFixed(2),
        avgLoss: avgLoss.toFixed(2),
        maxDrawdown: maxDrawdown.toFixed(1),
        sharpeRatio: sharpeRatio.toFixed(2),
        finalValue: currentValue.toFixed(0),
        strategy: strategy || "trend-following",
        rsi: indicators.rsi,
        macd: indicators.macd
      });
    } catch (error) {
      console.error("Error running backtest:", error);
      res.status(500).json({ error: "Failed to run backtest" });
    }
  });

  app.post("/api/ai/risk-reward", async (req, res) => {
    try {
      const { symbol, entryPrice: providedEntry } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ error: "Symbol is required" });
      }

      const quote = getStockQuote(symbol);
      const entryPrice = providedEntry || quote.price;
      
      const volatility = 0.02 + Math.random() * 0.03;
      const stopLossPercent = volatility + 0.01;
      const takeProfitPercent = volatility * 2 + 0.02;
      
      const stopLoss = entryPrice * (1 - stopLossPercent);
      const takeProfit = entryPrice * (1 + takeProfitPercent);
      
      const riskAmount = entryPrice - stopLoss;
      const rewardAmount = takeProfit - entryPrice;
      const ratio = (rewardAmount / riskAmount).toFixed(1);
      
      res.json({
        entryPrice: entryPrice.toFixed(2),
        stopLoss: stopLoss.toFixed(2),
        takeProfit: takeProfit.toFixed(2),
        riskAmount: riskAmount.toFixed(2),
        rewardAmount: rewardAmount.toFixed(2),
        ratio,
        riskPercent: ((riskAmount / entryPrice) * 100).toFixed(1),
        rewardPercent: ((rewardAmount / entryPrice) * 100).toFixed(1)
      });
    } catch (error) {
      console.error("Error calculating risk-reward:", error);
      res.status(500).json({ error: "Failed to calculate risk-reward" });
    }
  });

  app.get("/api/market/news", async (req, res) => {
    try {
      const headlines = getMarketNews();
      res.json({ headlines });
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  return httpServer;
}

function calculateRSI(prices: number[]): number {
  const changes = prices.slice(1).map((p, i) => p - prices[i]);
  const gains = changes.filter(c => c > 0);
  const losses = changes.filter(c => c < 0).map(c => Math.abs(c));
  
  const avgGain = gains.length > 0 ? gains.reduce((a, b) => a + b, 0) / 14 : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((a, b) => a + b, 0) / 14 : 0.01;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}
