import { Navbar } from "@/components/navbar";
import { TickerTape } from "@/components/ticker-tape";
import { Footer } from "@/components/footer";
import { FeaturesSection } from "@/components/features-section";
import { TimelineWidget } from "@/components/timeline-widget";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { 
  Sparkles, 
  ArrowRight, 
  CheckCircle2,
  Shield,
  Zap,
  TrendingUp,
  BarChart3,
  Brain
} from "lucide-react";

const benefits = [
  { icon: Brain, text: "AI-Powered Analysis", description: "Advanced machine learning models analyze market patterns" },
  { icon: TrendingUp, text: "Real-time Predictions", description: "Get instant predictions on stock movements" },
  { icon: Shield, text: "Risk Management", description: "Built-in tools to protect your investments" },
  { icon: Zap, text: "Instant Insights", description: "No more hours of research - get answers in seconds" },
  { icon: BarChart3, text: "Technical Indicators", description: "Auto-calculated RSI, MACD, and Moving Averages" },
  { icon: CheckCircle2, text: "Beginner Friendly", description: "Designed for investors of all experience levels" },
];

export default function Features() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <TickerTape />
      
      <main className="flex-1">
        <section className="py-16 bg-gradient-to-b from-background to-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <Badge variant="outline" className="mb-4 px-4 py-1">
                <Sparkles className="h-3 w-3 mr-2" />
                AI-Powered Features
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Everything You Need for
                <br />
                <span className="gradient-text">Smarter Trading</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Our AI co-pilot transforms complex market data into actionable insights, 
                helping you make confident investment decisions.
              </p>
            </motion.div>

            <div className="grid lg:grid-cols-3 gap-8 mb-16">
              <div className="lg:col-span-2">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <h2 className="text-2xl font-bold mb-6">Why Choose AI CoPilot?</h2>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {benefits.map((benefit, index) => (
                      <Card 
                        key={index}
                        className="p-4 border-border/50 bg-card/50 hover-elevate cursor-default"
                      >
                        <div className="flex items-start gap-3">
                          <div className="p-2 rounded-lg bg-primary/10">
                            <benefit.icon className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold mb-1">{benefit.text}</h3>
                            <p className="text-sm text-muted-foreground">{benefit.description}</p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="flex flex-col"
              >
                <h2 className="text-2xl font-bold mb-6">Latest Market News</h2>
                <div className="flex-1">
                  <TimelineWidget width={400} height={500} />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <FeaturesSection />

        <section className="py-20 bg-gradient-to-b from-muted/30 to-background">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Transform Your Trading?
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
                Join thousands of investors who are already using AI CoPilot to make smarter investment decisions.
              </p>
              <Button 
                size="lg" 
                className="gap-2 px-8 bg-gradient-to-r from-primary via-purple-500 to-cyan-500"
                data-testid="button-get-started"
              >
                Get Started Free
                <ArrowRight className="h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
