import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { useAuth } from "@/lib/auth-context";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Trophy,
  Target,
  BookOpen,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Loader2,
  Sparkles,
  Award,
  Zap,
  Shield,
  BarChart3,
  PieChart,
  Clock,
  CheckCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Stock {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  sector: string;
  country: string;
}

interface Holding {
  symbol: string;
  name: string;
  quantity: number;
  avgBuyPrice: number;
  currentPrice: number;
  currentValue: number;
  pnl: number;
  pnlPercent: number;
}

interface Portfolio {
  holdings: Holding[];
  totalValue: number;
  totalInvested: number;
  totalPnl: number;
  cashBalance: number;
}

interface Trade {
  id: string;
  symbol: string;
  type: string;
  quantity: number;
  price: number;
  total: number;
  createdAt: string;
}

interface Achievement {
  id: string;
  type: string;
  unlockedAt: string;
}

const achievementInfo: Record<string, { title: string; description: string; icon: typeof Trophy }> = {
  first_login: { title: "Welcome Aboard", description: "Created your account", icon: Sparkles },
  first_trade: { title: "First Trade", description: "Made your first trade", icon: ShoppingCart },
  ten_trades: { title: "Active Trader", description: "Completed 10 trades", icon: Zap },
  first_profit: { title: "In The Green", description: "Made your first profit", icon: TrendingUp },
};

const strategies = [
  {
    id: "momentum",
    name: "Momentum Strategy",
    description: "Buy when price is trending up with strong momentum. Follows the market direction.",
    risk: "Medium-High",
    icon: Zap,
  },
  {
    id: "value",
    name: "Value Investing",
    description: "Buy when RSI indicates oversold conditions. Look for undervalued stocks.",
    risk: "Medium",
    icon: Target,
  },
  {
    id: "growth",
    name: "Growth Strategy",
    description: "Buy when price is above moving average. Focus on stocks with growth potential.",
    risk: "High",
    icon: TrendingUp,
  },
];

export default function GamifiedInvesting() {
  const [, setLocation] = useLocation();
  const { user, updateBalance } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [selectedStrategy, setSelectedStrategy] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-1 flex items-center justify-center p-4">
          <Card className="max-w-md p-8 text-center">
            <Trophy className="h-16 w-16 mx-auto mb-4 text-primary" />
            <h1 className="text-2xl font-bold mb-2">Start Your Investing Journey</h1>
            <p className="text-muted-foreground mb-6">
              Create a free account to get ₹10,00,000 virtual cash and start practicing with real market data.
            </p>
            <Link href="/signin">
              <Button size="lg" className="w-full gap-2" data-testid="button-signin-cta">
                Get Started Free
                <ArrowUpRight className="h-4 w-4" />
              </Button>
            </Link>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  const { data: portfolio, isLoading: portfolioLoading } = useQuery<Portfolio>({
    queryKey: [`/api/portfolio/${user.id}`],
  });

  const { data: trades } = useQuery<Trade[]>({
    queryKey: [`/api/trades/${user.id}`],
  });

  const { data: achievements } = useQuery<Achievement[]>({
    queryKey: [`/api/achievements/${user.id}`],
  });

  const stocksQueryParam = searchQuery ? `search=${searchQuery}` : 'country=IN';
  const { data: stocks, isLoading: stocksLoading } = useQuery<Stock[]>({
    queryKey: [`/api/stocks?${stocksQueryParam}`],
  });

  const tradeMutation = useMutation({
    mutationFn: async ({ type, symbol, qty }: { type: string; symbol: string; qty: number }) => {
      const response = await apiRequest("POST", "/api/trade", {
        userId: user.id,
        userEmail: user.email,
        symbol,
        type,
        quantity: qty,
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/portfolio/${user.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/trades/${user.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/achievements/${user.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/user/${user.id}`] });
      
      const newBalance = (user.virtualBalance || 0) - (selectedStock?.price || 0) * quantity;
      updateBalance(newBalance);
      
      toast({
        title: "Trade Executed",
        description: `Successfully ${data.type === 'buy' ? 'bought' : 'sold'} at ₹${data.price.toFixed(2)}`,
      });
      setSelectedStock(null);
      setQuantity(1);
    },
    onError: (error: any) => {
      toast({
        title: "Trade Failed",
        description: error.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const { data: backtestResult, isLoading: backtestLoading, refetch: runBacktest } = useQuery({
    queryKey: ['/api/ai/backtest', selectedStrategy],
    queryFn: async () => {
      if (!selectedStrategy) return null;
      const response = await apiRequest("POST", "/api/ai/backtest", {
        symbol: "NSE:NIFTY50",
        strategy: selectedStrategy,
      });
      return response.json();
    },
    enabled: false,
  });

  const handleTrade = (type: "buy" | "sell") => {
    if (!selectedStock) return;
    tradeMutation.mutate({ type, symbol: selectedStock.symbol, qty: quantity });
  };

  const totalPortfolioValue = (portfolio?.totalValue || 0) + (portfolio?.cashBalance || 0);
  const todayPnl = portfolio?.totalPnl || 0;
  const todayPnlPercent = portfolio?.totalInvested ? (todayPnl / portfolio.totalInvested) * 100 : 0;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1">
        <section className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Trophy className="h-5 w-5 text-primary" />
                  <h1 className="text-2xl font-bold">Virtual Trading Simulator</h1>
                </div>
                <p className="text-muted-foreground">Practice investing with ₹10,00,000 virtual cash</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Available Cash</p>
                  <p className="text-xl font-bold text-green-500">
                    ₹{(portfolio?.cashBalance || user.virtualBalance || 0).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="p-4" data-testid="card-portfolio-value">
                <div className="flex items-center gap-2 mb-2">
                  <Wallet className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Portfolio Value</span>
                </div>
                <div className="text-xl font-bold">₹{totalPortfolioValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
              </Card>
              
              <Card className="p-4" data-testid="card-invested">
                <div className="flex items-center gap-2 mb-2">
                  <PieChart className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Invested</span>
                </div>
                <div className="text-xl font-bold">₹{(portfolio?.totalInvested || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
              </Card>
              
              <Card className="p-4" data-testid="card-pnl">
                <div className="flex items-center gap-2 mb-2">
                  {todayPnl >= 0 ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className="text-sm text-muted-foreground">Total P&L</span>
                </div>
                <div className={cn("text-xl font-bold", todayPnl >= 0 ? "text-green-500" : "text-red-500")}>
                  {todayPnl >= 0 ? "+" : ""}₹{todayPnl.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  <span className="text-sm ml-1">({todayPnlPercent.toFixed(1)}%)</span>
                </div>
              </Card>
              
              <Card className="p-4" data-testid="card-trades">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Total Trades</span>
                </div>
                <div className="text-xl font-bold">{trades?.length || 0}</div>
              </Card>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-6">
          <Tabs defaultValue="trade" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="trade" className="gap-2" data-testid="tab-trade">
                <ShoppingCart className="h-4 w-4" />
                Trade
              </TabsTrigger>
              <TabsTrigger value="portfolio" className="gap-2" data-testid="tab-portfolio">
                <PieChart className="h-4 w-4" />
                Portfolio
              </TabsTrigger>
              <TabsTrigger value="strategies" className="gap-2" data-testid="tab-strategies">
                <Target className="h-4 w-4" />
                Strategies
              </TabsTrigger>
              <TabsTrigger value="learn" className="gap-2" data-testid="tab-learn">
                <BookOpen className="h-4 w-4" />
                Learn
              </TabsTrigger>
            </TabsList>

            <TabsContent value="trade" className="mt-0">
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <Card className="p-4 mb-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search Indian stocks..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                        data-testid="input-search-stocks"
                      />
                    </div>
                  </Card>

                  <div className="grid sm:grid-cols-2 gap-3">
                    {stocksLoading ? (
                      <div className="col-span-2 flex items-center justify-center py-12">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    ) : (
                      (Array.isArray(stocks) ? stocks : []).slice(0, 12).map((stock) => {
                        const isPositive = stock.changePercent >= 0;
                        const isSelected = selectedStock?.symbol === stock.symbol;
                        
                        return (
                          <Card
                            key={stock.symbol}
                            className={cn(
                              "p-4 cursor-pointer transition-all",
                              isSelected ? "border-primary ring-1 ring-primary" : "hover:border-primary/50"
                            )}
                            onClick={() => setSelectedStock(stock)}
                            data-testid={`card-trade-stock-${stock.symbol.replace(':', '-')}`}
                          >
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h3 className="font-semibold">{stock.symbol.split(':')[1]}</h3>
                                <p className="text-xs text-muted-foreground truncate max-w-[150px]">{stock.name}</p>
                              </div>
                              <Badge 
                                variant="outline" 
                                className={cn(
                                  "text-xs",
                                  isPositive 
                                    ? "border-green-500/30 text-green-500 bg-green-500/10" 
                                    : "border-red-500/30 text-red-500 bg-red-500/10"
                                )}
                              >
                                {isPositive ? "+" : ""}{stock.changePercent.toFixed(2)}%
                              </Badge>
                            </div>
                            <div className="text-lg font-bold">
                              ₹{stock.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                            </div>
                          </Card>
                        );
                      })
                    )}
                  </div>
                </div>

                <div>
                  <Card className="p-4 sticky top-20">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <ShoppingCart className="h-4 w-4" />
                      Trade Panel
                    </h3>
                    
                    {selectedStock ? (
                      <div className="space-y-4">
                        <div className="p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold">{selectedStock.symbol.split(':')[1]}</span>
                            <Badge variant="outline" className="text-xs">{selectedStock.sector}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{selectedStock.name}</p>
                          <p className="text-2xl font-bold mt-2">
                            ₹{selectedStock.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </p>
                        </div>

                        <div>
                          <label className="text-sm text-muted-foreground mb-2 block">Quantity</label>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => setQuantity(Math.max(1, quantity - 1))}
                              data-testid="button-decrease-qty"
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                            <Input
                              type="number"
                              value={quantity}
                              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                              className="text-center"
                              min={1}
                              data-testid="input-quantity"
                            />
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => setQuantity(quantity + 1)}
                              data-testid="button-increase-qty"
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Order Value</span>
                            <span className="font-semibold">
                              ₹{(selectedStock.price * quantity).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <Button
                            className="w-full bg-green-600 hover:bg-green-700"
                            onClick={() => handleTrade("buy")}
                            disabled={tradeMutation.isPending}
                            data-testid="button-buy"
                          >
                            {tradeMutation.isPending ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <>
                                <ArrowUpRight className="h-4 w-4 mr-1" />
                                Buy
                              </>
                            )}
                          </Button>
                          <Button
                            variant="destructive"
                            className="w-full"
                            onClick={() => handleTrade("sell")}
                            disabled={tradeMutation.isPending}
                            data-testid="button-sell"
                          >
                            {tradeMutation.isPending ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <>
                                <ArrowDownRight className="h-4 w-4 mr-1" />
                                Sell
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <ShoppingCart className="h-12 w-12 mx-auto mb-3 opacity-50" />
                        <p>Select a stock to trade</p>
                      </div>
                    )}
                  </Card>

                  {achievements && achievements.length > 0 && (
                    <Card className="p-4 mt-4">
                      <h3 className="font-semibold mb-3 flex items-center gap-2">
                        <Award className="h-4 w-4 text-yellow-500" />
                        Achievements
                      </h3>
                      <div className="space-y-2">
                        {achievements.map((a) => {
                          const info = achievementInfo[a.type];
                          if (!info) return null;
                          const Icon = info.icon;
                          return (
                            <div key={a.id} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                              <div className="h-8 w-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
                                <Icon className="h-4 w-4 text-yellow-500" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">{info.title}</p>
                                <p className="text-xs text-muted-foreground">{info.description}</p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </Card>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="portfolio" className="mt-0">
              <Card className="p-4">
                <h3 className="font-semibold mb-4">Your Holdings</h3>
                {portfolioLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : portfolio?.holdings.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <PieChart className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p className="mb-2">No holdings yet</p>
                    <p className="text-sm">Start trading to build your portfolio</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {portfolio?.holdings.map((h) => {
                      const isPositive = h.pnl >= 0;
                      return (
                        <div
                          key={h.symbol}
                          className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                          data-testid={`holding-${h.symbol.replace(':', '-')}`}
                        >
                          <div>
                            <h4 className="font-semibold">{h.symbol.split(':')[1]}</h4>
                            <p className="text-sm text-muted-foreground">{h.name}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {h.quantity} shares @ ₹{h.avgBuyPrice.toFixed(2)} avg
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">₹{h.currentValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</p>
                            <p className={cn("text-sm", isPositive ? "text-green-500" : "text-red-500")}>
                              {isPositive ? "+" : ""}₹{h.pnl.toFixed(0)} ({h.pnlPercent.toFixed(1)}%)
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>

              {trades && trades.length > 0 && (
                <Card className="p-4 mt-4">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Recent Trades
                  </h3>
                  <div className="space-y-2">
                    {trades.slice(0, 10).map((t) => (
                      <div key={t.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 text-sm">
                        <div className="flex items-center gap-3">
                          <Badge variant={t.type === "buy" ? "default" : "destructive"} className="text-xs">
                            {t.type.toUpperCase()}
                          </Badge>
                          <span className="font-medium">{t.symbol.split(':')[1]}</span>
                          <span className="text-muted-foreground">x{t.quantity}</span>
                        </div>
                        <span className="font-medium">₹{t.total.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="strategies" className="mt-0">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-4">Test Trading Strategies</h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    Select a strategy to see how it would have performed on Nifty 50 over the last 90 days.
                  </p>
                  <div className="space-y-3">
                    {strategies.map((s) => {
                      const Icon = s.icon;
                      const isSelected = selectedStrategy === s.id;
                      return (
                        <Card
                          key={s.id}
                          className={cn(
                            "p-4 cursor-pointer transition-all",
                            isSelected ? "border-primary ring-1 ring-primary" : "hover:border-primary/50"
                          )}
                          onClick={() => setSelectedStrategy(s.id)}
                          data-testid={`card-strategy-${s.id}`}
                        >
                          <div className="flex items-start gap-3">
                            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                              <Icon className="h-5 w-5 text-primary" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="font-semibold">{s.name}</h4>
                                <Badge variant="outline" className="text-xs">{s.risk}</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{s.description}</p>
                            </div>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                  
                  <Button
                    className="w-full mt-4"
                    disabled={!selectedStrategy || backtestLoading}
                    onClick={() => runBacktest()}
                    data-testid="button-run-backtest"
                  >
                    {backtestLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Sparkles className="h-4 w-4 mr-2" />
                    )}
                    Run Backtest
                  </Button>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">Backtest Results</h3>
                  {backtestResult ? (
                    <Card className="p-4">
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="p-3 rounded-lg bg-muted/50">
                          <p className="text-xs text-muted-foreground mb-1">Win Rate</p>
                          <p className="text-2xl font-bold text-green-500">{backtestResult.winRate}%</p>
                        </div>
                        <div className="p-3 rounded-lg bg-muted/50">
                          <p className="text-xs text-muted-foreground mb-1">Total Return</p>
                          <p className={cn("text-2xl font-bold", parseFloat(backtestResult.profit) >= 0 ? "text-green-500" : "text-red-500")}>
                            {parseFloat(backtestResult.profit) >= 0 ? "+" : ""}{backtestResult.profit}%
                          </p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Total Trades</span>
                          <span className="font-medium">{backtestResult.totalTrades}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Avg Win</span>
                          <span className="font-medium text-green-500">+{backtestResult.avgWin}%</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Avg Loss</span>
                          <span className="font-medium text-red-500">-{backtestResult.avgLoss}%</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Max Drawdown</span>
                          <span className="font-medium text-red-500">-{backtestResult.maxDrawdown}%</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Sharpe Ratio</span>
                          <span className="font-medium">{backtestResult.sharpeRatio}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm pt-2 border-t">
                          <span className="text-muted-foreground">Final Value (₹10K start)</span>
                          <span className="font-bold">₹{parseInt(backtestResult.finalValue).toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                    </Card>
                  ) : (
                    <Card className="p-8 text-center text-muted-foreground">
                      <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>Select a strategy and click "Run Backtest" to see results</p>
                    </Card>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="learn" className="mt-0">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { title: "What is Stock Trading?", desc: "Learn the basics of buying and selling stocks", icon: BookOpen, level: "Beginner" },
                  { title: "Understanding P&L", desc: "How to calculate your profit and loss", icon: TrendingUp, level: "Beginner" },
                  { title: "Technical Analysis", desc: "Reading charts and using indicators", icon: BarChart3, level: "Intermediate" },
                  { title: "Risk Management", desc: "Protect your capital with proper sizing", icon: Shield, level: "Intermediate" },
                  { title: "Trading Strategies", desc: "Momentum, value, and growth investing", icon: Target, level: "Advanced" },
                  { title: "Portfolio Diversification", desc: "Don't put all eggs in one basket", icon: PieChart, level: "Beginner" },
                ].map((topic, i) => {
                  const Icon = topic.icon;
                  return (
                    <Card key={i} className="p-4 hover:border-primary/50 transition-all cursor-pointer">
                      <div className="flex items-start gap-3">
                        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold">{topic.title}</h4>
                            <Badge variant="outline" className="text-xs">{topic.level}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{topic.desc}</p>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <Footer />
    </div>
  );
}
