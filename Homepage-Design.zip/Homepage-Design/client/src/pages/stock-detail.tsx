import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/navbar";
import { AdvancedChart } from "@/components/advanced-chart";
import { AIChatPanel } from "@/components/ai-chat-panel";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  MessageSquare, 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown,
  Sparkles,
  AlertCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
  volume: string;
  marketCap: string;
}

export default function StockDetail() {
  const params = useParams<{ symbol: string }>();
  const symbol = decodeURIComponent(params.symbol || "NASDAQ:AAPL");
  const [chatOpen, setChatOpen] = useState(false);

  const { data: quote, isLoading, isError } = useQuery<StockQuote>({
    queryKey: [`/api/stocks/${encodeURIComponent(symbol)}`],
    refetchInterval: 30000,
  });

  const isPositive = (quote?.change || 0) >= 0;
  const displaySymbol = symbol.includes(':') ? symbol.split(':')[1] : symbol;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <div className="border-b border-border bg-card/50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link href="/stocks">
                <Button variant="ghost" size="icon" data-testid="button-back">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <div className="flex items-center gap-3 flex-wrap">
                  <h1 className="text-2xl font-bold">{displaySymbol}</h1>
                  {isLoading ? (
                    <Skeleton className="h-6 w-20" />
                  ) : isError ? (
                    <Badge variant="outline" className="border-red-500/30 text-red-500 bg-red-500/10">
                      <AlertCircle className="h-3 w-3 mr-1" />
                      Error
                    </Badge>
                  ) : (
                    <Badge 
                      variant="outline" 
                      className={cn(
                        isPositive 
                          ? "border-green-500/30 text-green-500 bg-green-500/10" 
                          : "border-red-500/30 text-red-500 bg-red-500/10"
                      )}
                    >
                      {isPositive ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                      {isPositive ? "+" : ""}{quote?.changePercent?.toFixed(2)}%
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{quote?.name || symbol}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 lg:gap-6">
              {isLoading ? (
                <div className="flex gap-6">
                  {[...Array(4)].map((_, i) => (
                    <div key={i}>
                      <Skeleton className="h-4 w-12 mb-1" />
                      <Skeleton className="h-6 w-16" />
                    </div>
                  ))}
                </div>
              ) : !isError && (
                <div className="flex gap-6 text-sm">
                  <div>
                    <span className="text-muted-foreground">Price</span>
                    <div className="font-semibold text-lg">${quote?.price?.toFixed(2)}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Change</span>
                    <div className={cn("font-semibold", isPositive ? "text-green-500" : "text-red-500")}>
                      {isPositive ? "+" : ""}{quote?.change?.toFixed(2)}
                    </div>
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-muted-foreground">High</span>
                    <div className="font-semibold">${quote?.high?.toFixed(2)}</div>
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-muted-foreground">Low</span>
                    <div className="font-semibold">${quote?.low?.toFixed(2)}</div>
                  </div>
                </div>
              )}
              
              <Button 
                onClick={() => setChatOpen(true)}
                className="gap-2"
                data-testid="button-open-ai-chat"
              >
                <Sparkles className="h-4 w-4" />
                AI Analysis
              </Button>
            </div>
          </div>
        </div>
      </div>

      <main className="flex-1 relative">
        <div className="h-[calc(100vh-140px)]">
          <AdvancedChart symbol={symbol} />
        </div>
      </main>

      <AIChatPanel 
        symbol={displaySymbol} 
        isOpen={chatOpen} 
        onClose={() => setChatOpen(false)} 
      />

      {!chatOpen && (
        <Button
          onClick={() => setChatOpen(true)}
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-30"
          size="icon"
          data-testid="button-floating-ai"
        >
          <MessageSquare className="h-6 w-6" />
        </Button>
      )}
    </div>
  );
}
