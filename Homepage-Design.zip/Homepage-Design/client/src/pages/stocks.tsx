import { Navbar } from "@/components/navbar";
import { StockList } from "@/components/stock-list";
import { Footer } from "@/components/footer";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Activity } from "lucide-react";

const marketStats = [
  { label: "S&P 500", value: "4,783.45", change: "+0.82%", isPositive: true },
  { label: "NASDAQ", value: "15,234.12", change: "+1.24%", isPositive: true },
  { label: "DOW", value: "37,891.25", change: "-0.15%", isPositive: false },
  { label: "Bitcoin", value: "$67,250", change: "+1.89%", isPositive: true },
];

export default function Stocks() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1">
        <section className="border-b border-border bg-card/50">
          <div className="container mx-auto px-4 py-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold mb-1">Markets</h1>
                <p className="text-muted-foreground">Track and analyze stocks, crypto, and more</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-green-500 pulse-live" />
                <span className="text-sm text-muted-foreground">Live data</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {marketStats.map((stat) => (
                <Card key={stat.label} className="p-4 border-border" data-testid={`card-market-${stat.label.toLowerCase().replace(' ', '-')}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                    {stat.isPositive ? (
                      <TrendingUp className="h-4 w-4 text-green-500" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <div className="text-xl font-bold">{stat.value}</div>
                  <div className={stat.isPositive ? "text-sm text-green-500" : "text-sm text-red-500"}>
                    {stat.change}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>
        
        <section className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold mb-1">Popular Stocks</h2>
              <p className="text-sm text-muted-foreground">Click any stock to view detailed analysis</p>
            </div>
            <Badge variant="secondary" className="gap-1.5">
              <Activity className="h-3 w-3" />
              {new Date().toLocaleDateString()}
            </Badge>
          </div>
          
          <StockList />
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
