import { motion } from "framer-motion";
import { 
  TrendingUp, 
  BarChart3, 
  Newspaper, 
  History, 
  Target, 
  Scale,
  ArrowUpRight,
  ArrowDownRight,
  ArrowRight
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

const features = [
  {
    title: "Trend Prediction",
    description: "ML-powered predictions on whether a stock will go up or down in the next few hours.",
    icon: TrendingUp,
    color: "text-blue-500",
    bgColor: "bg-blue-500/10",
    demo: (
      <div className="flex items-center gap-2 mt-4">
        <div className="flex-1 h-16 rounded-lg bg-green-500/10 flex items-center justify-center">
          <ArrowUpRight className="h-8 w-8 text-green-500" />
        </div>
        <div className="flex-1 h-16 rounded-lg bg-red-500/10 flex items-center justify-center">
          <ArrowDownRight className="h-8 w-8 text-red-500" />
        </div>
      </div>
    ),
  },
  {
    title: "Market Mood",
    description: "Sentiment analysis of financial news to understand market direction.",
    icon: Newspaper,
    color: "text-cyan-500",
    bgColor: "bg-cyan-500/10",
    demo: (
      <div className="mt-4 p-3 rounded-lg bg-muted/50">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-muted-foreground">Sentiment</span>
          <Badge variant="outline" className="text-xs bg-green-500/10 text-green-500 border-green-500/30">
            Positive
          </Badge>
        </div>
        <div className="w-full h-2 rounded-full bg-muted">
          <div className="h-full w-3/4 rounded-full bg-green-500 progress-animate" />
        </div>
      </div>
    ),
  },
  {
    title: "Buy/Sell Alerts",
    description: "Clear trading signals with confidence scores to guide your decisions.",
    icon: Target,
    color: "text-green-500",
    bgColor: "bg-green-500/10",
    demo: (
      <div className="flex items-center gap-2 mt-4">
        <Badge className="flex-1 justify-center py-1.5 bg-green-500 text-white">BUY</Badge>
        <Badge className="flex-1 justify-center py-1.5 bg-yellow-500 text-black">HOLD</Badge>
        <Badge className="flex-1 justify-center py-1.5 bg-red-500 text-white">SELL</Badge>
      </div>
    ),
  },
  {
    title: "Backtest Simulator",
    description: "Test AI predictions against historical data to see past performance.",
    icon: History,
    color: "text-orange-500",
    bgColor: "bg-orange-500/10",
    demo: (
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div className="p-2 rounded-md bg-muted/50">
          <div className="text-xs text-muted-foreground">Trades</div>
          <div className="text-sm font-bold">47</div>
        </div>
        <div className="p-2 rounded-md bg-green-500/10">
          <div className="text-xs text-muted-foreground">Win Rate</div>
          <div className="text-sm font-bold text-green-500">73%</div>
        </div>
        <div className="p-2 rounded-md bg-green-500/10">
          <div className="text-xs text-muted-foreground">Profit</div>
          <div className="text-sm font-bold text-green-500">+18%</div>
        </div>
      </div>
    ),
  },
  {
    title: "Risk Calculator",
    description: "Calculate potential risk vs reward before entering any trade.",
    icon: Scale,
    color: "text-pink-500",
    bgColor: "bg-pink-500/10",
    demo: (
      <div className="mt-4 space-y-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground w-12">Risk</span>
          <div className="flex-1 h-2 rounded-full bg-muted">
            <div className="h-full w-1/4 bg-red-500 rounded-full" />
          </div>
          <span className="text-xs text-red-500">-$250</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground w-12">Reward</span>
          <div className="flex-1 h-2 rounded-full bg-muted">
            <div className="h-full w-3/4 bg-green-500 rounded-full" />
          </div>
          <span className="text-xs text-green-500">+$750</span>
        </div>
      </div>
    ),
  },
  {
    title: "Technical Indicators",
    description: "Auto-calculated RSI, MACD, Moving Averages and more.",
    icon: BarChart3,
    color: "text-purple-500",
    bgColor: "bg-purple-500/10",
    demo: (
      <div className="flex items-center gap-2 mt-4">
        <div className="flex-1 p-2 rounded-md bg-muted/50 text-center">
          <div className="text-xs text-muted-foreground">RSI</div>
          <div className="text-sm font-bold text-purple-500">65.4</div>
        </div>
        <div className="flex-1 p-2 rounded-md bg-muted/50 text-center">
          <div className="text-xs text-muted-foreground">MA(20)</div>
          <div className="text-sm font-bold text-green-500">$178</div>
        </div>
        <div className="flex-1 p-2 rounded-md bg-muted/50 text-center">
          <div className="text-xs text-muted-foreground">MACD</div>
          <div className="text-sm font-bold text-blue-500">+2.3</div>
        </div>
      </div>
    ),
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20 section-gradient" id="features">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <Badge variant="secondary" className="mb-4">Features</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Everything you need to trade smarter
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Powerful AI-driven tools designed for both beginners and experienced traders.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
            >
              <Card 
                className="h-full p-6 border-border hover:border-border/80 feature-card"
                data-testid={`card-feature-${index}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={cn("p-2.5 rounded-lg", feature.bgColor)}>
                    <feature.icon className={cn("h-5 w-5", feature.color)} />
                  </div>
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
                {feature.demo}
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex flex-col items-center p-8 rounded-2xl bg-card border border-border">
            <h3 className="text-2xl font-bold mb-2">Ready to start trading smarter?</h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Get AI-powered insights on any stock in seconds. No complex charts required.
            </p>
            <Link href="/stocks">
              <Button size="lg" className="gap-2" data-testid="button-features-cta">
                Explore Stocks
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
