import { useEffect, useRef } from "react";

export function MarketSummary() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const existingScript = containerRef.current.querySelector('script');
    if (existingScript) return;

    const script = document.createElement("script");
    script.src = "https://widgets.tradingview-widget.com/w/en/tv-market-summary.js";
    script.type = "module";
    script.async = true;
    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current) {
        const scripts = containerRef.current.querySelectorAll('script');
        scripts.forEach(s => s.remove());
      }
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full" data-testid="widget-market-summary">
      <tv-market-summary direction="horizontal" />
    </div>
  );
}

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'tv-market-summary': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement> & { direction?: string }, HTMLElement>;
    }
  }
}
