import { useEffect, useRef, memo } from "react";
import { useTheme } from "@/lib/theme-provider";

interface AdvancedChartProps {
  symbol: string;
  onSymbolChange?: (symbol: string) => void;
}

function AdvancedChartComponent({ symbol }: AdvancedChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    if (!containerRef.current) return;

    containerRef.current.innerHTML = '';

    const widgetContainer = document.createElement("div");
    widgetContainer.className = "tradingview-widget-container__widget";
    widgetContainer.style.height = "calc(100% - 32px)";
    widgetContainer.style.width = "100%";
    containerRef.current.appendChild(widgetContainer);

    const copyright = document.createElement("div");
    copyright.className = "tradingview-widget-copyright";
    copyright.innerHTML = `<a href="https://www.tradingview.com/symbols/${symbol}/" rel="noopener nofollow" target="_blank"><span class="blue-text">${symbol} chart</span></a><span class="trademark"> by TradingView</span>`;
    containerRef.current.appendChild(copyright);

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";
    script.type = "text/javascript";
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: symbol,
      interval: "D",
      timezone: "exchange",
      theme: resolvedTheme,
      style: "0",
      locale: "en",
      allow_symbol_change: true,
      calendar: false,
      withdateranges: true,
      save_image: false,
      details: true,
      hotlist: true,
      support_host: "https://www.tradingview.com"
    });
    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
    };
  }, [symbol, resolvedTheme]);

  return (
    <div 
      ref={containerRef}
      className="tradingview-widget-container h-full w-full"
      data-testid="widget-advanced-chart"
    />
  );
}

export const AdvancedChart = memo(AdvancedChartComponent);
