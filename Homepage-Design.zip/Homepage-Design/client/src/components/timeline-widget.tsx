import { useEffect, useRef } from "react";
import { useTheme } from "@/lib/theme-provider";

interface TimelineWidgetProps {
  width?: number;
  height?: number;
}

export function TimelineWidget({ width = 400, height = 550 }: TimelineWidgetProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    if (!containerRef.current) return;

    containerRef.current.innerHTML = '';

    const widgetContainer = document.createElement("div");
    widgetContainer.className = "tradingview-widget-container__widget";
    containerRef.current.appendChild(widgetContainer);

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/external-embedding/embed-widget-timeline.js";
    script.type = "text/javascript";
    script.async = true;
    script.innerHTML = JSON.stringify({
      displayMode: "regular",
      feedMode: "all_symbols",
      colorTheme: resolvedTheme,
      isTransparent: false,
      locale: "en",
      width: width,
      height: height
    });
    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
    };
  }, [resolvedTheme, width, height]);

  return (
    <div 
      ref={containerRef} 
      className="tradingview-widget-container rounded-lg overflow-hidden border border-border"
      style={{ width, height }}
      data-testid="widget-timeline"
    />
  );
}
