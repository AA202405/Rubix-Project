import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

const stocks = [
  { symbol: "NSE:RELIANCE", name: "Reliance Industries", price: 2895.50, change: 34.20, changePercent: 1.20, currency: "₹" },
  { symbol: "NSE:TCS", name: "Tata Consultancy Services", price: 4125.80, change: 52.30, changePercent: 1.28, currency: "₹" },
  { symbol: "NSE:HDFCBANK", name: "HDFC Bank Ltd.", price: 1710.30, change: -12.40, changePercent: -0.72, currency: "₹" },
  { symbol: "NSE:INFY", name: "Infosys Ltd.", price: 1845.25, change: 28.50, changePercent: 1.57, currency: "₹" },
  { symbol: "NSE:ICICIBANK", name: "ICICI Bank Ltd.", price: 1245.75, change: 18.30, changePercent: 1.49, currency: "₹" },
  { symbol: "NSE:BHARTIARTL", name: "Bharti Airtel Ltd.", price: 1685.40, change: -8.60, changePercent: -0.51, currency: "₹" },
  { symbol: "NSE:SBIN", name: "State Bank of India", price: 785.40, change: 11.20, changePercent: 1.45, currency: "₹" },
  { symbol: "NSE:HINDUNILVR", name: "Hindustan Unilever", price: 2545.30, change: -15.40, changePercent: -0.60, currency: "₹" },
  { symbol: "NASDAQ:AAPL", name: "Apple Inc.", price: 178.52, change: 2.34, changePercent: 1.33, currency: "$" },
  { symbol: "NASDAQ:GOOGL", name: "Alphabet Inc.", price: 141.80, change: -0.95, changePercent: -0.67, currency: "$" },
  { symbol: "NASDAQ:NVDA", name: "NVIDIA Corp.", price: 875.28, change: 15.67, changePercent: 1.82, currency: "$" },
  { symbol: "BINANCE:BTCUSDT", name: "Bitcoin", price: 97250.00, change: 1250.00, changePercent: 1.30, currency: "$" },
];

export function StockList() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {stocks.map((stock) => {
        const isPositive = stock.change >= 0;
        const encodedSymbol = encodeURIComponent(stock.symbol);
        const displaySymbol = stock.symbol.split(':')[1];
        const isIndian = stock.symbol.startsWith('NSE:') || stock.symbol.startsWith('BSE:');
        
        return (
          <Link key={stock.symbol} href={`/stocks/${encodedSymbol}`}>
            <Card 
              className="group p-4 h-full border-border hover:border-primary/50 stock-card cursor-pointer transition-all duration-200"
              data-testid={`card-stock-${stock.symbol.replace(':', '-')}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-base">{displaySymbol}</h3>
                    {isIndian && (
                      <Badge variant="outline" className="text-[10px] py-0 px-1 border-orange-500/30 text-orange-500">
                        NSE
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{stock.name}</p>
                </div>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "shrink-0 ml-2",
                    isPositive 
                      ? "border-green-500/30 text-green-500 bg-green-500/10" 
                      : "border-red-500/30 text-red-500 bg-red-500/10"
                  )}
                >
                  {isPositive ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                  {isPositive ? "+" : ""}{stock.changePercent.toFixed(2)}%
                </Badge>
              </div>
              
              <div className="flex items-end justify-between">
                <div>
                  <span className="text-xl font-bold">
                    {stock.currency}{stock.price.toLocaleString(isIndian ? 'en-IN' : undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className={cn(
                    "text-sm ml-2",
                    isPositive ? "text-green-500" : "text-red-500"
                  )}>
                    {isPositive ? "+" : ""}{stock.change.toFixed(2)}
                  </span>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
            </Card>
          </Link>
        );
      })}
    </div>
  );
}
