import { useEffect, useRef } from "react";

export function TickerTape() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const existingScript = containerRef.current.querySelector('script');
    if (existingScript) return;

    const script = document.createElement("script");
    script.src = "https://widgets.tradingview-widget.com/w/en/tv-ticker-tape.js";
    script.type = "module";
    script.async = true;
    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current) {
        const scripts = containerRef.current.querySelectorAll('script');
        scripts.forEach(s => s.remove());
      }
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full border-b border-border/40 bg-card/50" data-testid="widget-ticker-tape">
      <tv-ticker-tape 
        symbols='FOREXCOM:SPXUSD,FOREXCOM:NSXUSD,FOREXCOM:DJI,FX:EURUSD,BITSTAMP:BTCUSD,BITSTAMP:ETHUSD,CMCMARKETS:GOLD,IG:BITCOIN,NASDAQ:GOOG,NASDAQ:AAPL'
      />
    </div>
  );
}

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'tv-ticker-tape': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement> & { symbols?: string }, HTMLElement>;
    }
  }
}
