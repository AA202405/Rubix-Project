import { useEffect, useRef, useState, useMemo } from "react";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const STOCK_NAMES = ["GOOGL", "AAPL", "MSFT", "AMZN", "TSLA", "META"];
const CHART_COLORS = {
  blue: "rgb(59, 130, 246)",
  green: "rgb(34, 197, 94)",
  red: "rgb(239, 68, 68)",
  purple: "rgb(168, 85, 247)",
};

function generateData(length: number, startValue: number) {
  const data = [];
  let prev = startValue;
  for (let i = 0; i < length; i++) {
    prev += 5 - Math.random() * 10;
    data.push({ x: i, y: prev });
  }
  return data;
}

export function ProgressiveChart() {
  const chartRef = useRef<ChartJS<"line">>(null);
  const [animationComplete, setAnimationComplete] = useState(false);
  
  const selectedStocks = useMemo(() => {
    const shuffled = [...STOCK_NAMES].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 2);
  }, []);

  const datasets = useMemo(() => {
    const data1 = generateData(200, 100);
    const data2 = generateData(200, 80);
    const data3 = generateData(200, 120);
    const data4 = generateData(200, 90);
    return [
      { data: data1, color: CHART_COLORS.blue, label: selectedStocks[0] || "GOOGL" },
      { data: data2, color: CHART_COLORS.green, label: selectedStocks[1] || "AAPL" },
      { data: data3, color: CHART_COLORS.purple, label: "Index 1" },
      { data: data4, color: CHART_COLORS.red, label: "Index 2" },
    ];
  }, [selectedStocks]);

  const totalDuration = 8000;
  const delayBetweenPoints = totalDuration / datasets[0].data.length;

  const chartData = {
    datasets: datasets.map((ds, idx) => ({
      label: ds.label,
      data: ds.data,
      borderColor: ds.color,
      backgroundColor: ds.color.replace("rgb", "rgba").replace(")", ", 0.1)"),
      borderWidth: 2,
      pointRadius: 0,
      tension: 0.1,
      fill: idx < 2,
    })),
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
      x: {
        type: "number" as const,
        easing: "linear" as const,
        duration: delayBetweenPoints,
        from: NaN,
        delay(ctx: any) {
          if (ctx.type !== "data" || ctx.xStarted) {
            return 0;
          }
          ctx.xStarted = true;
          return ctx.index * delayBetweenPoints;
        },
      },
      y: {
        type: "number" as const,
        easing: "linear" as const,
        duration: delayBetweenPoints,
        from: (ctx: any) => {
          if (ctx.index === 0) {
            return ctx.chart.scales.y.getPixelForValue(100);
          }
          return ctx.chart.getDatasetMeta(ctx.datasetIndex).data[ctx.index - 1]?.getProps(["y"], true).y;
        },
        delay(ctx: any) {
          if (ctx.type !== "data" || ctx.yStarted) {
            return 0;
          }
          ctx.yStarted = true;
          return ctx.index * delayBetweenPoints;
        },
      },
      onComplete: () => {
        setAnimationComplete(true);
      },
    },
    interaction: {
      intersect: false,
      mode: "index" as const,
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        enabled: true,
        backgroundColor: "rgba(0, 0, 0, 0.8)",
        titleColor: "#fff",
        bodyColor: "#fff",
        borderColor: "rgba(255, 255, 255, 0.1)",
        borderWidth: 1,
        padding: 12,
        displayColors: true,
      },
    },
    scales: {
      x: {
        type: "linear" as const,
        display: false,
      },
      y: {
        display: false,
      },
    },
  };

  return (
    <div className="relative w-full h-[400px] md:h-[500px]" data-testid="chart-progressive">
      <div className="absolute top-4 left-4 z-10 flex flex-wrap gap-3">
        {datasets.slice(0, 2).map((ds, idx) => (
          <div
            key={idx}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-card/80 backdrop-blur-sm border border-border/50"
          >
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: ds.color }}
            />
            <span className="text-sm font-medium">{ds.label}</span>
          </div>
        ))}
      </div>
      <Line ref={chartRef} data={chartData} options={options} />
    </div>
  );
}
