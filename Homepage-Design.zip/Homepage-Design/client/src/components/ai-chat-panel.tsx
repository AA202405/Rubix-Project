import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  MessageSquare, 
  X, 
  TrendingUp, 
  BarChart3, 
  Newspaper, 
  History, 
  Target, 
  Scale,
  Send,
  Loader2,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { TimelineWidget } from "./timeline-widget";
import { apiRequest } from "@/lib/queryClient";

interface Message {
  id: string;
  type: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

interface AIChatPanelProps {
  symbol: string;
  isOpen: boolean;
  onClose: () => void;
}

const features = [
  { id: "trend", name: "Trend Prediction", icon: TrendingUp, color: "text-blue-500" },
  { id: "mood", name: "Market Mood", icon: Newspaper, color: "text-cyan-500" },
  { id: "signals", name: "Buy/Sell Alerts", icon: Target, color: "text-green-500" },
  { id: "backtest", name: "Backtest", icon: History, color: "text-orange-500" },
  { id: "risk", name: "Risk Calculator", icon: Scale, color: "text-pink-500" },
  { id: "indicators", name: "Indicators", icon: BarChart3, color: "text-purple-500" },
];

interface AnimatedStep {
  text: string;
  status: "pending" | "loading" | "complete";
}

export function AIChatPanel({ symbol, isOpen, onClose }: AIChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeFeature, setActiveFeature] = useState<string | null>(null);
  const [animatedSteps, setAnimatedSteps] = useState<AnimatedStep[]>([]);
  const [showTimeline, setShowTimeline] = useState(false);
  const [result, setResult] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const fullSymbol = symbol.includes(':') ? symbol : `NASDAQ:${symbol}`;

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, animatedSteps]);

  const runAnimatedSteps = async (steps: string[]): Promise<void> => {
    setAnimatedSteps(steps.map(text => ({ text, status: "pending" })));
    
    for (let i = 0; i < steps.length; i++) {
      setAnimatedSteps(prev => 
        prev.map((step, idx) => ({
          ...step,
          status: idx === i ? "loading" : idx < i ? "complete" : "pending"
        }))
      );
      await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 600));
      setAnimatedSteps(prev => 
        prev.map((step, idx) => ({
          ...step,
          status: idx <= i ? "complete" : step.status
        }))
      );
    }
    
    await new Promise(resolve => setTimeout(resolve, 300));
  };

  const handleFeatureClick = async (featureId: string) => {
    if (isProcessing) return;
    
    setActiveFeature(featureId);
    setIsProcessing(true);
    setResult(null);
    setAnimatedSteps([]);

    try {
      switch (featureId) {
        case "trend":
          await runAnimatedSteps([
            `Fetching latest prices for ${symbol}...`,
            "Analyzing recent closing prices...",
            "Running price pattern analysis...",
            "Calling ML prediction model...",
            "Generating prediction with confidence score..."
          ]);
          
          const trendResponse = await apiRequest("POST", "/api/ai/trend-prediction", { symbol: fullSymbol });
          const trendData = await trendResponse.json();
          
          setResult({
            type: "trend",
            ...trendData
          });
          break;

        case "mood":
          setShowTimeline(true);
          await new Promise(resolve => setTimeout(resolve, 2000));
          setShowTimeline(false);
          
          await runAnimatedSteps([
            "Fetching top stories and recent market data...",
            "Reading and processing financial reports...",
            "Performing sentiment analysis as top-tier research analyst...",
            "Calculating sentiment score across multiple sources...",
            "Consolidating results and preparing presentation..."
          ]);
          
          const sentimentResponse = await apiRequest("POST", "/api/ai/sentiment-analysis", { symbol: fullSymbol });
          const sentimentData = await sentimentResponse.json();
          
          setResult({
            type: "mood",
            ...sentimentData
          });
          break;

        case "signals":
          await runAnimatedSteps([
            "Gathering current market conditions...",
            "Analyzing technical indicators (RSI, MACD, Moving Averages)...",
            "Evaluating price action and volume...",
            "Consulting prediction model...",
            "Generating trading signal..."
          ]);
          
          const signalResponse = await apiRequest("POST", "/api/ai/trading-signal", { symbol: fullSymbol });
          const signalData = await signalResponse.json();
          
          setResult({
            type: "signals",
            ...signalData
          });
          break;

        case "backtest":
          await runAnimatedSteps([
            "Loading historical price data (30 days)...",
            "Running AI predictions on historical data...",
            "Comparing predictions vs actual results...",
            "Calculating performance metrics...",
            "Generating backtest report..."
          ]);
          
          const backtestResponse = await apiRequest("POST", "/api/ai/backtest", { symbol: fullSymbol });
          const backtestData = await backtestResponse.json();
          
          setResult({
            type: "backtest",
            ...backtestData
          });
          break;

        case "risk":
          await runAnimatedSteps([
            "Fetching current price data...",
            "Calculating volatility metrics...",
            "Determining optimal stop-loss levels...",
            "Computing risk-reward scenarios...",
            "Preparing risk analysis report..."
          ]);
          
          const riskResponse = await apiRequest("POST", "/api/ai/risk-reward", { symbol: fullSymbol });
          const riskData = await riskResponse.json();
          
          setResult({
            type: "risk",
            ...riskData
          });
          break;

        case "indicators":
          await runAnimatedSteps([
            "Fetching real-time price data...",
            "Calculating Moving Averages (20, 50, 200)...",
            "Computing RSI and MACD indicators...",
            "Analyzing Bollinger Bands...",
            "Generating indicator summary..."
          ]);
          
          const indicatorsResponse = await fetch(`/api/stocks/${encodeURIComponent(fullSymbol)}/indicators`);
          const indicatorsData = await indicatorsResponse.json();
          
          const rsiSignal = indicatorsData.rsi < 30 ? "Oversold" : indicatorsData.rsi > 70 ? "Overbought" : "Neutral";
          const macdSignal = indicatorsData.macd > 0 ? "Bullish" : "Bearish";
          
          setResult({
            type: "indicators",
            ...indicatorsData,
            rsiSignal,
            macdSignal
          });
          break;
      }
    } catch (error) {
      console.error("Error processing feature:", error);
      setResult({
        type: "error",
        message: "Failed to process request. Please try again."
      });
    }

    setIsProcessing(false);
  };

  const handleSendMessage = () => {
    if (!inputValue.trim() || isProcessing) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setInputValue("");

    setTimeout(() => {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: `I can help you analyze ${symbol}. Please use one of the feature buttons above for specific analysis like Trend Prediction, Market Mood, or Buy/Sell Signals.`,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, response]);
    }, 1000);
  };

  const renderResult = () => {
    if (!result) return null;

    if (result.type === "error") {
      return (
        <Card className="p-4 bg-destructive/10 border-destructive/50">
          <p className="text-sm text-destructive">{result.message}</p>
        </Card>
      );
    }

    switch (result.type) {
      case "trend":
        return (
          <Card className="p-4 bg-card/50 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold">Trend Prediction</h4>
              <Badge 
                className={cn(
                  "text-white",
                  result.prediction === "UP" ? "bg-green-500" : "bg-red-500"
                )}
              >
                {result.prediction === "UP" ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {result.prediction}
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Confidence</span>
                <span className="font-medium">{result.confidence}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-muted">
                <div 
                  className={cn(
                    "h-full rounded-full transition-all duration-500",
                    result.prediction === "UP" ? "bg-green-500" : "bg-red-500"
                  )}
                  style={{ width: `${result.confidence}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Expected Move</span>
                <span className={cn("font-medium", result.prediction === "UP" ? "text-green-500" : "text-red-500")}>
                  {result.priceChange}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mt-3">{result.reasoning}</p>
            </div>
          </Card>
        );

      case "mood":
        return (
          <Card className="p-4 bg-card/50 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold">Market Sentiment</h4>
              <Badge 
                className={cn(
                  "text-white",
                  result.sentiment === "Positive" ? "bg-green-500" : "bg-red-500"
                )}
              >
                {result.sentiment}
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-3xl font-bold">{result.score}</span>
                <span className="text-muted-foreground">/100</span>
              </div>
              <div className="w-full h-3 rounded-full bg-muted">
                <div 
                  className={cn(
                    "h-full rounded-full transition-all duration-500",
                    result.sentiment === "Positive" 
                      ? "bg-gradient-to-r from-green-500 to-cyan-500" 
                      : "bg-gradient-to-r from-red-500 to-orange-500"
                  )}
                  style={{ width: `${result.score}%` }}
                />
              </div>
              <p className="text-sm text-muted-foreground">{result.summary}</p>
            </div>
          </Card>
        );

      case "signals":
        return (
          <Card className="p-4 bg-card/50 border-border/50">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold">Trading Signal</h4>
              <Badge 
                className={cn(
                  "text-lg px-4 py-1",
                  result.signal === "BUY" && "bg-green-500 text-white",
                  result.signal === "HOLD" && "bg-yellow-500 text-black",
                  result.signal === "SELL" && "bg-red-500 text-white"
                )}
              >
                {result.signal}
              </Badge>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Confidence</span>
                <span className="font-medium">{result.confidence}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-muted">
                <div 
                  className={cn(
                    "h-full rounded-full",
                    result.signal === "BUY" && "bg-green-500",
                    result.signal === "HOLD" && "bg-yellow-500",
                    result.signal === "SELL" && "bg-red-500"
                  )}
                  style={{ width: `${result.confidence}%` }}
                />
              </div>
              <p className="text-sm text-muted-foreground">{result.reasoning}</p>
            </div>
          </Card>
        );

      case "backtest":
        return (
          <Card className="p-4 bg-card/50 border-border/50">
            <h4 className="font-semibold mb-4">Backtest Results (30 Days)</h4>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="text-center p-2 rounded-md bg-muted/50">
                <div className="text-2xl font-bold">{result.totalTrades}</div>
                <div className="text-xs text-muted-foreground">Trades</div>
              </div>
              <div className="text-center p-2 rounded-md bg-green-500/10">
                <div className="text-2xl font-bold text-green-500">{result.winRate}%</div>
                <div className="text-xs text-muted-foreground">Win Rate</div>
              </div>
              <div className="text-center p-2 rounded-md bg-green-500/10">
                <div className="text-2xl font-bold text-green-500">+{result.profit}%</div>
                <div className="text-xs text-muted-foreground">Profit</div>
              </div>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Avg Win: <span className="text-green-500">${result.avgWin}</span></span>
              <span className="text-muted-foreground">Avg Loss: <span className="text-red-500">${result.avgLoss}</span></span>
            </div>
          </Card>
        );

      case "risk":
        return (
          <Card className="p-4 bg-card/50 border-border/50">
            <h4 className="font-semibold mb-4">Risk-Reward Analysis</h4>
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2 text-center text-sm">
                <div className="p-2 rounded-md bg-muted/50">
                  <div className="text-xs text-muted-foreground">Entry</div>
                  <div className="font-semibold">${result.entryPrice}</div>
                </div>
                <div className="p-2 rounded-md bg-red-500/10">
                  <div className="text-xs text-muted-foreground">Stop Loss</div>
                  <div className="font-semibold text-red-500">${result.stopLoss}</div>
                </div>
                <div className="p-2 rounded-md bg-green-500/10">
                  <div className="text-xs text-muted-foreground">Take Profit</div>
                  <div className="font-semibold text-green-500">${result.takeProfit}</div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground w-14">Risk</span>
                  <div className="flex-1 h-3 rounded-full bg-muted">
                    <div className="h-full rounded-full bg-red-500" style={{ width: `${Math.min(parseFloat(result.riskPercent) * 10, 100)}%` }} />
                  </div>
                  <span className="text-xs text-red-500 w-20 text-right">-${result.riskAmount} ({result.riskPercent}%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground w-14">Reward</span>
                  <div className="flex-1 h-3 rounded-full bg-muted">
                    <div className="h-full rounded-full bg-green-500" style={{ width: `${Math.min(parseFloat(result.rewardPercent) * 10, 100)}%` }} />
                  </div>
                  <span className="text-xs text-green-500 w-20 text-right">+${result.rewardAmount} ({result.rewardPercent}%)</span>
                </div>
              </div>
              <div className="text-center pt-2 border-t border-border/50">
                <span className="text-sm text-muted-foreground">Risk:Reward = </span>
                <span className="text-lg font-bold text-green-500">1:{result.ratio}</span>
              </div>
            </div>
          </Card>
        );

      case "indicators":
        return (
          <Card className="p-4 bg-card/50 border-border/50">
            <h4 className="font-semibold mb-4">Technical Indicators</h4>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                <span className="text-sm">RSI (14)</span>
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{result.rsi}</span>
                  <Badge variant="outline" className={cn(
                    result.rsiSignal === "Oversold" && "border-green-500 text-green-500",
                    result.rsiSignal === "Overbought" && "border-red-500 text-red-500",
                    result.rsiSignal === "Neutral" && "border-yellow-500 text-yellow-500"
                  )}>
                    {result.rsiSignal}
                  </Badge>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-sm">
                <div className="p-2 rounded-md bg-muted/50">
                  <div className="text-xs text-muted-foreground">MA(20)</div>
                  <div className="font-semibold">${result.ma20}</div>
                </div>
                <div className="p-2 rounded-md bg-muted/50">
                  <div className="text-xs text-muted-foreground">MA(50)</div>
                  <div className="font-semibold">${result.ma50}</div>
                </div>
                <div className="p-2 rounded-md bg-muted/50">
                  <div className="text-xs text-muted-foreground">MA(200)</div>
                  <div className="font-semibold">${result.ma200}</div>
                </div>
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                <span className="text-sm">MACD</span>
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{result.macd}</span>
                  <Badge variant="outline" className={cn(
                    result.macdSignal === "Bullish" ? "border-green-500 text-green-500" : "border-red-500 text-red-500"
                  )}>
                    {result.macdSignal}
                  </Badge>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-center text-sm">
                <div className="p-2 rounded-md bg-muted/50">
                  <div className="text-xs text-muted-foreground">Bollinger Upper</div>
                  <div className="font-semibold">${result.bollingerUpper}</div>
                </div>
                <div className="p-2 rounded-md bg-muted/50">
                  <div className="text-xs text-muted-foreground">Bollinger Lower</div>
                  <div className="font-semibold">${result.bollingerLower}</div>
                </div>
              </div>
            </div>
          </Card>
        );

      default:
        return null;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-background border-l border-border z-50 flex flex-col"
            data-testid="panel-ai-chat"
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">AI Analysis - {symbol}</h3>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-chat">
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="p-3 border-b border-border">
              <div className="grid grid-cols-3 gap-2">
                {features.map((feature) => (
                  <Button
                    key={feature.id}
                    variant="outline"
                    size="sm"
                    className={cn(
                      "flex flex-col h-auto py-2 gap-1",
                      activeFeature === feature.id && "border-primary bg-primary/10"
                    )}
                    onClick={() => handleFeatureClick(feature.id)}
                    disabled={isProcessing}
                    data-testid={`button-feature-${feature.id}`}
                  >
                    <feature.icon className={cn("h-4 w-4", feature.color)} />
                    <span className="text-xs">{feature.name}</span>
                  </Button>
                ))}
              </div>
            </div>

            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
              <div className="space-y-4">
                {showTimeline && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="mb-4"
                  >
                    <TimelineWidget width={350} height={300} />
                  </motion.div>
                )}

                {animatedSteps.length > 0 && (
                  <Card className="p-4 bg-card/50 border-border/50">
                    <div className="space-y-3">
                      {animatedSteps.map((step, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                          <div className="mt-0.5">
                            {step.status === "loading" ? (
                              <Loader2 className="h-4 w-4 text-primary animate-spin" />
                            ) : step.status === "complete" ? (
                              <CheckCircle2 className="h-4 w-4 text-green-500" />
                            ) : (
                              <div className="h-4 w-4 rounded-full border-2 border-muted" />
                            )}
                          </div>
                          <span className={cn(
                            "text-sm",
                            step.status === "pending" && "text-muted-foreground",
                            step.status === "loading" && "text-foreground",
                            step.status === "complete" && "text-muted-foreground"
                          )}>
                            {step.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  </Card>
                )}

                {result && !isProcessing && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    {renderResult()}
                  </motion.div>
                )}

                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      "flex",
                      message.type === "user" ? "justify-end" : "justify-start"
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[80%] rounded-lg px-4 py-2",
                        message.type === "user"
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      )}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                ))}

                {!activeFeature && !isProcessing && messages.length === 0 && (
                  <div className="text-center py-8">
                    <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h4 className="font-medium mb-2">AI Analysis Ready</h4>
                    <p className="text-sm text-muted-foreground">
                      Select a feature above to get AI-powered insights for {symbol}
                    </p>
                  </div>
                )}
              </div>
            </ScrollArea>

            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask a question..."
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  disabled={isProcessing}
                  data-testid="input-chat-message"
                />
                <Button 
                  size="icon" 
                  onClick={handleSendMessage}
                  disabled={isProcessing || !inputValue.trim()}
                  data-testid="button-send-message"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
