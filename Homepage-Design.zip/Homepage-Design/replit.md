# AI CoPilot - Financial Trading Platform

## Overview
AI CoPilot is a TradingView-inspired financial trading platform that helps beginner investors make smarter trading decisions using AI-powered analysis. The platform includes a gamified virtual trading simulator as its unique selling proposition (USP), allowing beginners to practice with ₹10,00,000 virtual cash.

## Recent Changes
- **January 2026**: Gamified Investing Feature (USP)
  - Virtual trading simulator with ₹10,00,000 starting balance
  - Buy/sell stocks with real-time simulated prices
  - Portfolio dashboard with holdings, P&L tracking, performance metrics
  - Strategy testing: Momentum, Value Investing, and Growth strategies
  - Achievements system (First Login, First Trade, 10 Trades, First Profit)
  - Educational resources for beginner investors

- **January 2026**: Authentication System
  - Sign-in page with email/password authentication
  - Dummy auth that auto-creates users for any credentials
  - User session management with localStorage persistence
  - "Get Started" button redirects to sign-in, then to stocks page

- **January 2026**: Indian Stock Market Coverage
  - 70+ stocks including NSE/BSE indices (Nifty 50, Sensex, Bank Nifty)
  - Major Indian companies: Reliance, TCS, HDFC Bank, Infosys, ICICI Bank
  - Sectors covered: Banking, IT, Auto, FMCG, Pharma, Energy, Infrastructure
  - Indian Rupee (₹) formatting for NSE/BSE stocks

- **January 2026**: Enhanced Backtesting
  - Three preset strategies: Momentum, Value, Growth
  - Realistic metrics: Sharpe Ratio, Max Drawdown, Win Rate
  - 90-day historical data analysis
  - Strategy comparison and performance simulation

## Project Architecture

### Frontend (client/)
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom dark theme design system
- **State Management**: TanStack Query for server state, Context for auth
- **Animations**: Framer Motion for smooth transitions
- **Charts**: Chart.js for progressive line chart, TradingView widgets for real-time data
- **UI Components**: Shadcn UI component library

### Backend (server/)
- **Framework**: Express.js with TypeScript
- **AI Integration**: Google Gemini AI API for predictions and analysis
- **Data**: Simulated stock data with realistic patterns
- **Storage**: In-memory storage for users, portfolio, trades, achievements

### Key Features
1. **Virtual Trading Simulator** - Practice trading with ₹10,00,000 virtual cash
2. **Trend Prediction Model** - ML-powered price direction predictions
3. **Market Mood Detector** - Sentiment analysis with news integration
4. **Smart Buy/Sell Alerts** - Clear trading signals with confidence scores
5. **Strategy Backtester** - Test Momentum/Value/Growth strategies
6. **Risk-Reward Calculator** - Position sizing and risk analysis
7. **Achievement System** - Gamified milestones for learning progress

### File Structure
```
client/
├── src/
│   ├── components/
│   │   ├── ai-chat-panel.tsx    # AI analysis slide-out panel
│   │   ├── advanced-chart.tsx   # TradingView chart widget
│   │   ├── features-section.tsx # Features bento grid (on homepage)
│   │   ├── footer.tsx           # Site footer
│   │   ├── hero-section.tsx     # Homepage hero with chart
│   │   ├── navbar.tsx           # Top navigation with user menu
│   │   ├── progressive-chart.tsx # Animated line chart
│   │   ├── stock-list.tsx       # Stock grid cards with Indian stocks
│   │   └── theme-toggle.tsx     # Dark/light mode switch
│   ├── pages/
│   │   ├── home.tsx             # Landing page with hero + features
│   │   ├── signin.tsx           # Sign-in/Sign-up page
│   │   ├── stocks.tsx           # Stock market overview
│   │   ├── stock-detail.tsx     # Individual stock chart + AI analysis
│   │   └── gamified-investing.tsx # Virtual trading simulator
│   └── lib/
│       ├── auth-context.tsx     # Auth state management
│       ├── theme-provider.tsx   # Theme context
│       └── queryClient.ts       # TanStack Query setup
server/
├── routes.ts                    # API endpoints (auth, portfolio, trading)
├── gemini.ts                    # Gemini AI integration
├── stock-data.ts                # Stock database (70+ stocks)
└── storage.ts                   # In-memory storage for users, trades
```

### API Endpoints

#### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login (auto-creates user if not exists)
- `GET /api/user/:userId` - Get user details

#### Portfolio & Trading
- `GET /api/portfolio/:userId` - Get portfolio with holdings and P&L
- `POST /api/trade` - Execute buy/sell trade
- `GET /api/trades/:userId` - Get trade history
- `GET /api/achievements/:userId` - Get user achievements

#### Stock Data
- `GET /api/stocks` - List all stocks (with search/filter)
- `GET /api/stocks/:symbol` - Get stock quote
- `GET /api/stocks/:symbol/history` - Get price history
- `GET /api/stocks/:symbol/indicators` - Get technical indicators

#### AI Analysis
- `POST /api/ai/trend-prediction` - Get AI trend prediction
- `POST /api/ai/sentiment-analysis` - Get sentiment analysis
- `POST /api/ai/trading-signal` - Get buy/sell/hold signal
- `POST /api/ai/backtest` - Run strategy backtest
- `POST /api/ai/risk-reward` - Calculate risk-reward ratio

## User Preferences
- Dark mode as default theme
- Clean, professional design aesthetic
- Focus on beginner-friendly explanations
- Internal navigation for all stock links
- Indian Rupee formatting for NSE/BSE stocks
- Consistent spacing and color tokens throughout

## Development Notes
- Authentication is dummy (no real validation) for MVP
- Virtual balance starts at ₹10,00,000 (10 Lakh)
- TradingView widgets require external scripts loaded dynamically
- Gemini API key stored in GEMINI_API_KEY secret
- All AI features have fallback logic if API fails
- yahoo-finance2 package installed for future real data integration
